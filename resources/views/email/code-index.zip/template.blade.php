
<!DOCTYPE html><!--[if IE]>  <html class="ie"> <![endif]-->
<html>
	<head>
		<meta charset="utf-8" />
		<title>
		</title>
		<link rel="stylesheet" type="text/css" href="http://35.240.140.159/images/201811/style.css" />
	</head>
	<body>
		<div class="stl_01">
			<div class="stl_02">
				<object data="http://35.240.140.159/images/201811/img_03.svg" type="image/svg+xml" class="stl_03" style="position:absolute; width:98em; height:129.3333em;">
					<embed src="http://35.240.140.159/images/201811/img_03.svg" type="image/svg+xml" class="stl_03" />
				</object>
			</div>
			<div class="layer">
				<div class="stl_04 stl_05">
					<div style="position:absolute; top:25.3579em; left:12.575em;"><span class="stl_06 stl_07 stl_08">KICC &nbsp;</span></div>
					<div style="position:absolute; top:40.873em; left:12.575em;"><span class="stl_09 stl_07 stl_10">Korea &nbsp;</span></div>
					<div style="position:absolute; top:45.7174em; left:12.575em;"><span class="stl_09 stl_07 stl_11" style="word-spacing:0.183em;">IT Cooperation &nbsp;</span></div>
					<div style="position:absolute; top:50.5618em; left:12.575em;"><span class="stl_09 stl_07 stl_11">Center &nbsp;</span></div>
					<div style="position:absolute; top:55.4061em; left:12.575em;"><span class="stl_09 stl_07 stl_11">Hanoi &nbsp;</span></div>
					<div style="position:absolute; top:73.5064em; left:12.3758em;"><span class="stl_12 stl_07 stl_08">E-JOURNAL &nbsp;</span></div>
					<div style="position:absolute; top:118.6921em; left:84.5997em;"><span class="stl_13 stl_14 stl_10" style="word-spacing:-0.0166em;">Vol 4 &nbsp;</span></div>
					<div style="position:absolute; top:122.8954em; left:65.6398em;"><span class="stl_15 stl_16 stl_10" style="word-spacing:-0.0117em;">NOVEMBER 2018 &nbsp;</span></div>
				</div>
			</div>
		</div>
		<div class="stl_01">
			<div class="stl_02">
				<object data="http://35.240.140.159/images/201811/img_04.svg" type="image/svg+xml" class="stl_03" style="position:absolute; width:98em; height:129.3333em;">
					<embed src="http://35.240.140.159/images/201811/img_04.svg" type="image/svg+xml" class="stl_03" />
				</object>
			</div>
			<div class="layer">
				<div class="stl_04 stl_05">
					<div style="position:absolute; top:98.9255em; left:15.0136em;"><span class="stl_17 stl_07 stl_11" style="word-spacing:0.1835em;">BRIEFING ON VIET</span><span class="stl_17 stl_07 stl_11" style="word-spacing:-0.0009em;"> NAM</span><span class="stl_17 stl_07 stl_11" style="word-spacing:0.275em;"> PAY</span><span class="stl_17 stl_07 stl_11" style="word-spacing:0.1829em;"> TELEVISION &nbsp;</span></div>
					<div style="position:absolute; top:104.0226em; left:23.4068em;"><span class="stl_17 stl_07 stl_08" style="word-spacing:0.1834em;">AND OTT TELEVISION MARKET &nbsp;</span></div>
				</div>
			</div>
		</div>
		<div class="stl_01">
			<div class="stl_02">
				<object data="http://35.240.140.159/images/201811/img_08.svg" type="image/svg+xml" class="stl_03" style="position:absolute; width:98em; height:129.3333em;">
					<embed src="http://35.240.140.159/images/201811/img_08.svg" type="image/svg+xml" class="stl_03" />
				</object>
			</div>
			<div class="layer">
				<div class="stl_04 stl_05">
					<div style="position:absolute; top:11.1572em; left:11.8371em;"><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;">Vietnam Pay Television market overview &nbsp;</span></div>
					<div style="position:absolute; top:17.8602em; left:11.8371em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.071em;">The Pay-TV market in Vietnam has a signi&#x1F;cant increase in terms of subscribers and revenue of TV &nbsp;</span></div>
					<div style="position:absolute; top:20.0272em; left:11.8371em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.011em;">advertising. The number of subscribers of Pay-TV in 2017 is 13.2 Million with total revenue of pay TV &nbsp;</span></div>
					<div style="position:absolute; top:22.1942em; left:11.8371em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.021em;">in 2017 is 7.500 Billion VND (330 Million USD). The number of pay TV channels increase steadily in the &nbsp;</span></div>
					<div style="position:absolute; top:24.3612em; left:11.8371em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.052em;">north and center of Vietnam (Ha Noi and Da Nang) but signi&#x1F;cantly in the south (Ho Chi Minh City &nbsp;</span></div>
					<div style="position:absolute; top:26.5282em; left:11.8371em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.257em;">and Can Tho). 75% of households in the urban cities are Pay-TV subscribers. The number of &nbsp;</span></div>
					<div style="position:absolute; top:28.6952em; left:11.8371em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">subscribers is estimated to grow by 20% - 25% per year. &nbsp;</span></div>
					<div style="position:absolute; top:72.3121em; left:28.3976em;"><span class="stl_22 stl_23 stl_10" style="word-spacing:0em;">Figure 1: Pay TV subscribers share (2016) and the growth &nbsp;</span></div>
					<div style="position:absolute; top:116.8327em; left:36.1526em;"><span class="stl_22 stl_23 stl_10" style="word-spacing:0em;">Figure 2: VietNam PayTV landscape &nbsp;</span></div>
					<div style="position:absolute; top:122.1699em; left:68.642em;"><span class="stl_24 stl_25 stl_26" style="word-spacing:-0.0106em;">KICC E-JOURNAL - Vol 4</span><span class="stl_27 stl_28 stl_29" style="word-spacing:1.3704em;"> 01 &nbsp;</span></div>
				</div>
			</div>
		</div>
		<div class="stl_01">
			<div class="stl_02">
				<object data="http://35.240.140.159/images/201811/img_09.svg" type="image/svg+xml" class="stl_03" style="position:absolute; width:98em; height:129.3333em;">
					<embed src="http://35.240.140.159/images/201811/img_09.svg" type="image/svg+xml" class="stl_03" />
				</object>
			</div>
			<div class="layer">
				<div class="stl_04 stl_05">
					<div style="position:absolute; top:9.7984em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.007em;">In 2016, the regulation was made by the MIC which allows pay-TV providers to have maximum 30% &nbsp;</span></div>
					<div style="position:absolute; top:11.9654em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.03em;">of foreign channels of the total number of channels. It explains that the regulation is to “boost the &nbsp;</span></div>
					<div style="position:absolute; top:14.1324em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">subscription-based pay TV market” by helping domestic channels and TV program producers. &nbsp;</span></div>
					<div style="position:absolute; top:18.4664em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.194em;">Cable TV has been greatly developed in Vietnam over the recent years. There are three main &nbsp;</span></div>
					<div style="position:absolute; top:20.6334em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.004em;">companies which provide cable TV. 1st VTVcab is a subsidiary of VTV, 2nd Vietnam Cable TV (HTVC) &nbsp;</span></div>
					<div style="position:absolute; top:22.8004em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.027em;">is owned by HTV, 3rd the state-owned Saigontourist Cable Television Company (SCTV).</span><span class="stl_20 stl_21 stl_10" style="word-spacing:0.158em;"> They</span><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.027em;"> supply &nbsp;</span></div>
					<div style="position:absolute; top:24.9674em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.166em;">both national and international channels with SDTV (Standard De&#x1F;nition Television) and HDTV &nbsp;</span></div>
					<div style="position:absolute; top:27.1344em; left:12.4066em;"><span class="stl_20 stl_21 stl_10">(</span></div>
					<div style="position:absolute; top:29.3014em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">a government plan of restructuring state-owned companies. &nbsp;</span></div>
					<div style="position:absolute; top:27.1344em; left:12.9272em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.022em;">High De&#x1F;nition Television). VTVcab and SCTV were going privatize at the beginning of 2016, due to &nbsp;</span></div>
					<div style="position:absolute; top:33.6354em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.14em;">Cable service is the main service of pay TV market accounting for 80.8% of the revenue of this &nbsp;</span></div>
					<div style="position:absolute; top:35.8024em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.086em;">market in 2015. There are 85% of households in Ho Chi Minh City and Hanoi connected to cable &nbsp;</span></div>
					<div style="position:absolute; top:37.9694em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.111em;">market in 2015. Market share of cable TV service providers in terms of subscribers</span><span class="stl_20 stl_21 stl_10" style="word-spacing:0.434em;"> in</span><span class="stl_20 stl_21 stl_10" style="word-spacing:0.111em;"> 2015 is</span><span class="stl_20 stl_21 stl_10" style="word-spacing:0.111em;"> as &nbsp;</span></div>
					<div style="position:absolute; top:40.1364em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">follows: VTVcab was the market leader followed by SCTV, HTCV, and others (Viettel, VNPT, etc). &nbsp;</span></div>
					<div style="position:absolute; top:47.2253em; left:12.5343em;"><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;">Television channels overview &nbsp;</span></div>
					<div style="position:absolute; top:54.3851em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.066em;">Popular TV channels of Vietnam are di&#x1E;erent between north and south. The markets in the north &nbsp;</span></div>
					<div style="position:absolute; top:56.5521em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.086em;">and the center of Vietnam are dominated by some while the south of Vietnam has more various &nbsp;</span></div>
					<div style="position:absolute; top:58.7191em; left:12.4066em;"><span class="stl_20 stl_21 stl_10">channels. &nbsp;</span></div>
					<div style="position:absolute; top:63.0531em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.056em;">At Hanoi market (the North of Vietnam), 60% of market share belongs to VTV channels (VTV3 and &nbsp;</span></div>
					<div style="position:absolute; top:65.2201em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.024em;">VTV1). 11% is the local channel, HN1.</span><span class="stl_20 stl_21 stl_10" style="word-spacing:0.164em;"> At</span><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.024em;"> Danang market (the Centre of Vietnam): 4 leading</span><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.024em;"> channels &nbsp;</span></div>
					<div style="position:absolute; top:67.3871em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.022em;">compose of 75% market share. They are DVTV (27,9%), VTV3 (24,6%), DRT (local channel: 13,2%) and &nbsp;</span></div>
					<div style="position:absolute; top:69.5541em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.263em;">VTV1 (10,2%). VNPT (MyTV) holds 75% of IPTV market and 35% shares of payTV market. At &nbsp;</span></div>
					<div style="position:absolute; top:71.7211em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.05em;">Hochiminh market (the South of Vietnam), top 5 market shares are as follows: Vinh Long 1 (9.4%), &nbsp;</span></div>
					<div style="position:absolute; top:73.8881em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">SCTV14 (4.90%), SCTV9 (4.3%), Vinh Long 2 (3,6%), and VTC7 – Today TV (3.5%) &nbsp;</span></div>
					<div style="position:absolute; top:78.2221em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.028em;">The di&#x1E;erent favor for TV channels in the di&#x1E;erent regions could explain the di&#x1E;erences of culture in &nbsp;</span></div>
					<div style="position:absolute; top:80.3891em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.08em;">each region. The styles, the humor or type of shows in each area are signi&#x1F;cant to distinguish so &nbsp;</span></div>
					<div style="position:absolute; top:82.5561em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">does their preference about TV channels. &nbsp;</span></div>
					<div style="position:absolute; top:86.8901em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">VTV has six main channels which deal with the following subjects: &nbsp;</span></div>
					<div style="position:absolute; top:91.2241em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">VTV1 – political, economic, culture and social news &nbsp;</span></div>
					<div style="position:absolute; top:93.3911em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">VTV2 – education, science, technology, news &nbsp;</span></div>
					<div style="position:absolute; top:95.5581em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">VTV3 – sport, entertainment, economic news &nbsp;</span></div>
					<div style="position:absolute; top:97.7251em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">VTV4 – home a&#x1E;airs, international news &nbsp;</span></div>
					<div style="position:absolute; top:99.8921em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">VTV5 – local news &nbsp;</span></div>
					<div style="position:absolute; top:102.0591em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">VTV6 – youth channel &nbsp;</span></div>
					<div style="position:absolute; top:106.3931em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.033em;">Besides the national VTV channels, each city or province also has their own television stations. These &nbsp;</span></div>
					<div style="position:absolute; top:108.5601em; left:12.4066em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">channels are free to view although programs are in Vietnamese. &nbsp;</span></div>
					<div style="position:absolute; top:122.4428em; left:68.4673em;"><span class="stl_24 stl_25 stl_30" style="word-spacing:-0.0118em;">KICC E-JOURNAL - Vol 4 &nbsp;</span></div>
					<div style="position:absolute; top:122.3082em; left:86.5997em;"><span class="stl_27 stl_28 stl_10">0</span></div>
					<div style="position:absolute; top:122.3082em; left:87.6191em;"><span class="stl_27 stl_28 stl_10">2</span></div>
				</div>
			</div>
		</div>
		<div class="stl_01">
			<div class="stl_02">
				<object data="http://35.240.140.159/images/201811/img_10.svg" type="image/svg+xml" class="stl_03" style="position:absolute; width:98em; height:129.3333em;">
					<embed src="http://35.240.140.159/images/201811/img_10.svg" type="image/svg+xml" class="stl_03" />
				</object>
			</div>
			<div class="layer">
				<div class="stl_04 stl_05">
					<div style="position:absolute; top:11.1021em; left:12.4544em;"><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;">Broadband Internet &amp; Mobile internet overview &nbsp;</span></div>
					<div style="position:absolute; top:17.4489em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.101em;">In January 2014, 56 companies were granted to provide Internet services which include Internet &nbsp;</span></div>
					<div style="position:absolute; top:19.6159em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.344em;">application in telecommunication. Most of the companies are business-to-business services &nbsp;</span></div>
					<div style="position:absolute; top:21.7829em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.002em;">providers. For individuals and household customers, Viettel, VNPT and FPT hold most of the market &nbsp;</span></div>
					<div style="position:absolute; top:23.9499em; left:12.4552em;"><span class="stl_20 stl_21 stl_10">share. &nbsp;</span></div>
					<div style="position:absolute; top:28.2839em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.037em;">Current types of Internet connection available in Vietnam market is Fiber to the home (FTTH) with &nbsp;</span></div>
					<div style="position:absolute; top:30.4509em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.011em;">the average broadband speed for basic package (both download and upload speed) is 12-16 MBps &nbsp;</span></div>
					<div style="position:absolute; top:32.6179em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">and average price for FTTH package is 12 USD/month. &nbsp;</span></div>
					<div style="position:absolute; top:36.9519em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.08em;">By the end of 2017, Vietnam has about 11.2 million &#x1F;xed broadband internet subscribers, mostly &nbsp;</span></div>
					<div style="position:absolute; top:39.1189em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.006em;">household and business consumers approximate of 49.8 million internet users. FTTH is preferred in &nbsp;</span></div>
					<div style="position:absolute; top:41.2859em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.017em;">big cities due to better quality and speed, but ADSL does better in the suburbs and countryside due &nbsp;</span></div>
					<div style="position:absolute; top:43.4529em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">to the lower prices. &nbsp;</span></div>
					<div style="position:absolute; top:47.7869em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.116em;">There are 4 current 4G mobile telecom operators in Vietnam: Viettel, Vinaphone, MobiFone and &nbsp;</span></div>
					<div style="position:absolute; top:49.9539em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">Vietnamobile. Three of them (Viettel, Vinaphone, MobiFone) are state-owned companies. &nbsp;</span></div>
					<div style="position:absolute; top:56.573em; left:12.4544em;"><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;">Broadband Internet &amp; Mobile internet overview &nbsp;</span></div>
					<div style="position:absolute; top:63.4711em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.091em;">OTT (Over-the-Top) application is an app or services provide a service without requiring users to &nbsp;</span></div>
					<div style="position:absolute; top:65.6381em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.094em;">subscribe to a traditional cable or satellite service. For example, Skype, a well-known application &nbsp;</span></div>
					<div style="position:absolute; top:67.8051em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">which provides video call services on the Internet or Whatapp, a popular mobile app can work with &nbsp;</span></div>
					<div style="position:absolute; top:69.9721em; left:12.4552em;"><span class="stl_20 stl_21 stl_10">3</span></div>
					<div style="position:absolute; top:69.9721em; left:13.3957em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">G or wi&#x1F; instead of traditional mobile signal. &nbsp;</span></div>
					<div style="position:absolute; top:74.3061em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.036em;">In Vietnam, there is quite a number of mobile OTT available from popular foreign apps such as Viber, &nbsp;</span></div>
					<div style="position:absolute; top:76.4731em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.013em;">Whatsapp, Kakaotalk, Line, to apps from domestic providers such as Zalo, Mocha, Viettalk, etc. Two &nbsp;</span></div>
					<div style="position:absolute; top:78.6401em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.005em;">type of services are available:</span><span class="stl_20 stl_21 stl_10" style="word-spacing:0.222em;"> OTT</span><span class="stl_20 stl_21 stl_10" style="word-spacing:0.005em;"> without Interconnect (ap-ap), free of charge such as Line,</span><span class="stl_20 stl_21 stl_10" style="word-spacing:0.005em;"> Skype, &nbsp;</span></div>
					<div style="position:absolute; top:80.8071em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.271em;">Zalo, etc and with Inerconnect ( Ap- PSTN/PLMN), chargeable such as Viber-out, Skype-Out, &nbsp;</span></div>
					<div style="position:absolute; top:82.9741em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">Viettalk-out/in, Mocha, etc. &nbsp;</span></div>
					<div style="position:absolute; top:87.3081em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.028em;">The biggest OTT mobile app is Zalo with more than 80 million users, and about 32 million of them &nbsp;</span></div>
					<div style="position:absolute; top:89.4751em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.039em;">are regular users in October 2016 according to company press release. Zalo is an OTT-app which was &nbsp;</span></div>
					<div style="position:absolute; top:91.6421em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.112em;">created and developed by VNG, Vietnamese technology company specializing in digital content &nbsp;</span></div>
					<div style="position:absolute; top:93.8091em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.151em;">and online entertainment, social networking, and e-commerce. Zalo was launched in 2012 and &nbsp;</span></div>
					<div style="position:absolute; top:95.9761em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.099em;">quickly became the most popular OTT mobile app in a short time. It was not just only a tool for &nbsp;</span></div>
					<div style="position:absolute; top:98.1431em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.016em;">communication but also it has di&#x1E;erent functions such as news or online searching and other more. &nbsp;</span></div>
					<div style="position:absolute; top:100.3101em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.141em;">They are planning to integrate e-commerce and other business assistance apps to Zalo in near &nbsp;</span></div>
					<div style="position:absolute; top:102.4771em; left:12.4552em;"><span class="stl_20 stl_21 stl_10">future. &nbsp;</span></div>
					<div style="position:absolute; top:106.8111em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.028em;">Viber is the second biggest OTT mobile apps with over 23 million users (2015) but they shut down &nbsp;</span></div>
					<div style="position:absolute; top:108.9781em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.044em;">the Vietnam representative o&#x1D;ce after a year of its operation. Viber claimed they established new &nbsp;</span></div>
					<div style="position:absolute; top:111.1451em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.038em;">headquarters in the Philippines for the Southeast Asian region. However, this explanation left rooms &nbsp;</span></div>
					<div style="position:absolute; top:113.3121em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.087em;">for suspicion over the closure of second largest OTT app in Vietnam. A representative of a major &nbsp;</span></div>
					<div style="position:absolute; top:115.4791em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.002em;">local mobile network made a comment that “Viber Vietnam did not have a positive business model &nbsp;</span></div>
					<div style="position:absolute; top:117.6461em; left:12.4552em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">in addition the competition from domestic OTTs made it di&#x1D;cult for Viber to survive here”. &nbsp;</span></div>
					<div style="position:absolute; top:122.4428em; left:68.6003em;"><span class="stl_24 stl_25 stl_30" style="word-spacing:-0.0118em;">KICC E-JOURNAL - Vol 4 &nbsp;</span></div>
					<div style="position:absolute; top:122.3082em; left:86.7327em;"><span class="stl_27 stl_28 stl_10">0</span></div>
					<div style="position:absolute; top:122.3082em; left:87.752em;"><span class="stl_27 stl_28 stl_10">3</span></div>
				</div>
			</div>
		</div>
		<div class="stl_01">
			<div class="stl_02">
				<object data="http://35.240.140.159/images/201811/img_11.svg" type="image/svg+xml" class="stl_03" style="position:absolute; width:98em; height:129.3333em;">
					<embed src="http://35.240.140.159/images/201811/img_11.svg" type="image/svg+xml" class="stl_03" />
				</object>
			</div>
			<div class="layer">
				<div class="stl_04 stl_05">
					<div style="position:absolute; top:10.1412em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.022em;">Facebook is one of the biggest OTTs apps in Vietnam with around of 30 million users (2015) who are &nbsp;</span></div>
					<div style="position:absolute; top:12.3082em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.026em;">active, and 27 million users are from mobile environment. It is arguably the biggest social network &nbsp;</span></div>
					<div style="position:absolute; top:14.4752em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.069em;">in Vietnam now and does not have any competitor in the market. Facebook users use the app to &nbsp;</span></div>
					<div style="position:absolute; top:16.6422em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.15em;">connect with friends, catch up with news and visit entertainment content, fashion and beauty, &nbsp;</span></div>
					<div style="position:absolute; top:18.8092em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">dining categories and promotion pages run by brands and shops. &nbsp;</span></div>
					<div style="position:absolute; top:23.1432em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">Line has about 4 million users and Kakaotalk has about 1 million users by 2014, however, these two &nbsp;</span></div>
					<div style="position:absolute; top:25.3102em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.014em;">OTT apps closed their o&#x1D;ce shortly after launching due to the harsh competition against domestic &nbsp;</span></div>
					<div style="position:absolute; top:27.4772em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.097em;">OTT apps. Beside those apps, major mobile network operators have their own OTT apps such as &nbsp;</span></div>
					<div style="position:absolute; top:29.6442em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.243em;">Viettel with Mocha, MobiFone with WiTalk with about 3-4 million users for each app. Those &nbsp;</span></div>
					<div style="position:absolute; top:31.8112em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.048em;">operators do not aim to compete Zalo or Viber but rather go after additional services for roaming &nbsp;</span></div>
					<div style="position:absolute; top:33.9782em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">and foreign markets. &nbsp;</span></div>
					<div style="position:absolute; top:38.3122em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.27em;">For television market, K+ cooperate with Irdeto&#x1C; to launch the &#x1F;rst commercial OTT app as &nbsp;</span></div>
					<div style="position:absolute; top:40.4792em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.214em;">multi-screen support to o&#x1E;er their content for various devices and browsers. Meanwhile, VTV &nbsp;</span></div>
					<div style="position:absolute; top:42.6463em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.041em;">collaborated with Harmonic&#x1B;</span><span class="stl_20 stl_21 stl_10" style="word-spacing:0.13em;"> for</span><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.041em;"> its own live OTT app. They addressed that OTT TV becomes</span><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.041em;"> popular &nbsp;</span></div>
					<div style="position:absolute; top:44.8133em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.099em;">to Vietnamese consumers and they want to set the standard for the services in Vietnam market. &nbsp;</span></div>
					<div style="position:absolute; top:46.9803em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.136em;">Giant OTT Television Net&#x1A;ix (https://www.net&#x1A;ix.com/vn ) has o&#x1D;cially jumped in the Viet Nam &nbsp;</span></div>
					<div style="position:absolute; top:49.1473em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">market in 2016 but does not still open any local o&#x1D;ce here yet up to now. &nbsp;</span></div>
					<div style="position:absolute; top:53.4813em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.002em;">In order to provide services at low service fees, OTT television companies have to spend big money &nbsp;</span></div>
					<div style="position:absolute; top:55.6483em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.047em;">on copyright, content production, technology and infrastructure. Analysts said that FPT Play, Zing &nbsp;</span></div>
					<div style="position:absolute; top:57.8153em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.059em;">TV and VTVgo, the best known OTT TVs in Vietnam, are pouring ‘tons of money’ into investments &nbsp;</span></div>
					<div style="position:absolute; top:59.9823em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.171em;">and incurring losses of billions of dong each year. OTT television companies have to compete &nbsp;</span></div>
					<div style="position:absolute; top:62.1493em; left:12.5753em;"><span class="stl_20 stl_21 stl_10">&#x1F;</span></div>
					<div style="position:absolute; top:62.1493em; left:13.5341em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.011em;">ercely with each other to obtain the copyright for hot content. Meanwhile, Vietnamese users only &nbsp;</span></div>
					<div style="position:absolute; top:64.3163em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.079em;">want the content free of charge while providers of the pirated video try every possible means to &nbsp;</span></div>
					<div style="position:absolute; top:66.4833em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.032em;">dodge the laws. OTT service providers in Vietnam cannot satisfy all the requirements on copyright &nbsp;</span></div>
					<div style="position:absolute; top:68.6503em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">for content as of today. &nbsp;</span></div>
					<div style="position:absolute; top:72.9843em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.349em;">Some OTT service providers have good telecommunication platforms but they don’t have &nbsp;</span></div>
					<div style="position:absolute; top:75.1513em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.036em;">experience in content production. Other service providers come from content producing but they &nbsp;</span></div>
					<div style="position:absolute; top:77.3183em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.252em;">either have dead applications or cannot develop multi-platforms. VTV, the leader in content &nbsp;</span></div>
					<div style="position:absolute; top:79.4853em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.014em;">production, has had to diversify its content production models. VTV can make VTV video programs &nbsp;</span></div>
					<div style="position:absolute; top:81.6523em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.087em;">on its own calling for investment from di&#x1E;erent sources especially from private sectors and buys &nbsp;</span></div>
					<div style="position:absolute; top:83.8193em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.079em;">copyright from other content producers. Most OTT TV customers don’t care if the programs they &nbsp;</span></div>
					<div style="position:absolute; top:85.9863em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.243em;">watch are copyrighted or pirated. Vietnamese have the habit of watching TV free of charge &nbsp;</span></div>
					<div style="position:absolute; top:88.1533em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.035em;">demanding high quality services. This practice together with the limited online payment methods &nbsp;</span></div>
					<div style="position:absolute; top:90.3203em; left:12.5753em;"><span class="stl_20 stl_21 stl_10">(</span></div>
					<div style="position:absolute; top:90.3203em; left:13.0959em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.107em;">currently, payment can be made with credit cards, game cards or telecom cards), make it more &nbsp;</span></div>
					<div style="position:absolute; top:92.4873em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.005em;">challenging for OTT service providers. There are no o&#x1D;cial statistics about the number of units that &nbsp;</span></div>
					<div style="position:absolute; top:94.6543em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.003em;">violate TV copyright and the losses caused by piracy. However, the representative of the Ministry of &nbsp;</span></div>
					<div style="position:absolute; top:96.8213em; left:12.5753em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.034em;">Information &amp; Communication (MIC) a&#x1D;rmed that piracy on the internet has reached an ‘alarming &nbsp;</span></div>
					<div style="position:absolute; top:98.9883em; left:12.5753em;"><span class="stl_20 stl_21 stl_10">level’. &nbsp;</span></div>
					<div style="position:absolute; top:111.1461em; left:12.5745em;"><span class="stl_31 stl_23 stl_10">1</span></div>
					<div style="position:absolute; top:111.0495em; left:13.1639em;"><span class="stl_32 stl_23 stl_10" style="word-spacing:0em;">A global &#x1F;rm in TV industry &nbsp;</span></div>
					<div style="position:absolute; top:112.7995em; left:13.1639em;"><span class="stl_32 stl_23 stl_10" style="word-spacing:0em;">A global &#x1F;rm in TV industry &nbsp;</span></div>
					<div style="position:absolute; top:112.8961em; left:12.5745em;"><span class="stl_31 stl_23 stl_10">2</span></div>
					<div style="position:absolute; top:122.4428em; left:68.6214em;"><span class="stl_24 stl_25 stl_30" style="word-spacing:-0.0118em;">KICC E-JOURNAL - Vol 4 &nbsp;</span></div>
					<div style="position:absolute; top:122.3082em; left:86.7538em;"><span class="stl_27 stl_28 stl_10">0</span></div>
					<div style="position:absolute; top:122.3082em; left:87.7731em;"><span class="stl_27 stl_28 stl_10">4</span></div>
				</div>
			</div>
		</div>
		<div class="stl_01">
			<div class="stl_02">
				<object data="http://35.240.140.159/images/201811/img_12.svg" type="image/svg+xml" class="stl_03" style="position:absolute; width:98em; height:129.3333em;">
					<embed src="http://35.240.140.159/images/201811/img_12.svg" type="image/svg+xml" class="stl_03" />
				</object>
			</div>
			<div class="layer">
				<div class="stl_04 stl_05">
					<div style="position:absolute; top:11.1021em; left:12.3658em;"><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;">List of some OTT TV providers in Viet Nam &nbsp;</span></div>
					<div style="position:absolute; top:19.9629em; left:12.3653em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">Below table shows some o&#x1D;cial legally OTT TV providers in Viet Nam &nbsp;</span></div>
					<div style="position:absolute; top:26.5021em; left:48.6263em;"><span class="stl_33 stl_34 stl_10" style="word-spacing:0em;">Kind of &nbsp;</span></div>
					<div style="position:absolute; top:28.5024em; left:48.8188em;"><span class="stl_33 stl_34 stl_10">Owner &nbsp;</span></div>
					<div style="position:absolute; top:26.5021em; left:68.438em;"><span class="stl_33 stl_34 stl_10">Target &nbsp;</span></div>
					<div style="position:absolute; top:28.5024em; left:67.507em;"><span class="stl_33 stl_34 stl_10">Audience &nbsp;</span></div>
					<div style="position:absolute; top:26.5021em; left:79.2863em;"><span class="stl_33 stl_34 stl_10">Target &nbsp;</span></div>
					<div style="position:absolute; top:28.5024em; left:78.8505em;"><span class="stl_33 stl_34 stl_10">location &nbsp;</span></div>
					<div style="position:absolute; top:27.5013em; left:13.8363em;"><span class="stl_33 stl_34 stl_10">No. &nbsp;</span></div>
					<div style="position:absolute; top:27.5013em; left:25.0625em;"><span class="stl_33 stl_34 stl_10">URLs &nbsp;</span></div>
					<div style="position:absolute; top:27.5013em; left:39.269em;"><span class="stl_33 stl_34 stl_10">Owner &nbsp;</span></div>
					<div style="position:absolute; top:27.5013em; left:57.5968em;"><span class="stl_33 stl_34 stl_10">Content &nbsp;</span></div>
					<div style="position:absolute; top:33.9769em; left:37.9769em;"><span class="stl_20 stl_21 stl_35">FPT &nbsp;</span></div>
					<div style="position:absolute; top:36.1439em; left:37.9769em;"><span class="stl_20 stl_21 stl_35">Telecom &nbsp;</span></div>
					<div style="position:absolute; top:33.9769em; left:48.6433em;"><span class="stl_20 stl_21 stl_35">Private &nbsp;</span></div>
					<div style="position:absolute; top:33.975em; left:57.1389em;"><span class="stl_20 stl_21 stl_35">News, &nbsp;</span></div>
					<div style="position:absolute; top:36.1421em; left:57.1389em;"><span class="stl_20 stl_21 stl_35">movies &nbsp;</span></div>
					<div style="position:absolute; top:33.9769em; left:67.9153em;"><span class="stl_20 stl_21 stl_35">Popular &nbsp;</span></div>
					<div style="position:absolute; top:42.0178em; left:67.9153em;"><span class="stl_20 stl_21 stl_35">Youth &nbsp;</span></div>
					<div style="position:absolute; top:33.9769em; left:77.5586em;"><span class="stl_20 stl_21 stl_35">National &nbsp;</span></div>
					<div style="position:absolute; top:36.1439em; left:77.5586em;"><span class="stl_20 stl_21 stl_35">wide &nbsp;</span></div>
					<div style="position:absolute; top:34.2912em; left:14.5473em;"><span class="stl_20 stl_21 stl_10">1</span></div>
					<div style="position:absolute; top:34.2087em; left:19.3525em;"><span class="stl_36 stl_21 stl_10">https://fptplay.vn &nbsp;</span></div>
					<div style="position:absolute; top:42.0178em; left:37.9769em;"><span class="stl_20 stl_21 stl_35">VNG &nbsp;</span></div>
					<div style="position:absolute; top:42.0178em; left:48.6433em;"><span class="stl_20 stl_21 stl_35">Private &nbsp;</span></div>
					<div style="position:absolute; top:42.0178em; left:57.1389em;"><span class="stl_20 stl_21 stl_35">News, &nbsp;</span></div>
					<div style="position:absolute; top:44.1848em; left:57.1389em;"><span class="stl_20 stl_21 stl_35">movies &nbsp;</span></div>
					<div style="position:absolute; top:42.0178em; left:77.5586em;"><span class="stl_20 stl_21 stl_35">National &nbsp;</span></div>
					<div style="position:absolute; top:44.1848em; left:77.5586em;"><span class="stl_20 stl_21 stl_35">wide &nbsp;</span></div>
					<div style="position:absolute; top:42.3339em; left:14.5473em;"><span class="stl_20 stl_21 stl_10">2</span></div>
					<div style="position:absolute; top:50.4173em; left:14.5473em;"><span class="stl_20 stl_21 stl_10">3</span></div>
					<div style="position:absolute; top:42.2514em; left:19.3525em;"><span class="stl_36 stl_21 stl_10">https://tv.zing.vn &nbsp;</span></div>
					<div style="position:absolute; top:49.6006em; left:48.6433em;"><span class="stl_20 stl_21 stl_35">State &nbsp;</span></div>
					<div style="position:absolute; top:51.7676em; left:48.6433em;"><span class="stl_20 stl_21 stl_35">and &nbsp;</span></div>
					<div style="position:absolute; top:53.9346em; left:48.6433em;"><span class="stl_20 stl_21 stl_35">Private &nbsp;</span></div>
					<div style="position:absolute; top:56.1016em; left:48.6433em;"><span class="stl_20 stl_21 stl_35">Join &nbsp;</span></div>
					<div style="position:absolute; top:50.1011em; left:37.9769em;"><span class="stl_20 stl_21 stl_35" style="word-spacing:0em;">K plus &nbsp;</span></div>
					<div style="position:absolute; top:50.1011em; left:57.1389em;"><span class="stl_20 stl_21 stl_35">News, &nbsp;</span></div>
					<div style="position:absolute; top:52.2681em; left:57.1389em;"><span class="stl_20 stl_21 stl_35">movies &nbsp;</span></div>
					<div style="position:absolute; top:50.1011em; left:67.9153em;"><span class="stl_20 stl_21 stl_35">Popular &nbsp;</span></div>
					<div style="position:absolute; top:50.1011em; left:77.5586em;"><span class="stl_20 stl_21 stl_35">National &nbsp;</span></div>
					<div style="position:absolute; top:52.2681em; left:77.5586em;"><span class="stl_20 stl_21 stl_35">wide &nbsp;</span></div>
					<div style="position:absolute; top:50.3348em; left:19.3525em;"><span class="stl_36 stl_21 stl_10">https://www.kplus.vn &nbsp;</span></div>
					<div style="position:absolute; top:60.6011em; left:37.9769em;"><span class="stl_20 stl_21 stl_35">VTV &nbsp;</span></div>
					<div style="position:absolute; top:68.6844em; left:37.9769em;"><span class="stl_20 stl_21 stl_35">VTV &nbsp;</span></div>
					<div style="position:absolute; top:76.7678em; left:37.9769em;"><span class="stl_20 stl_21 stl_35">VTV &nbsp;</span></div>
					<div style="position:absolute; top:84.8511em; left:37.9769em;"><span class="stl_20 stl_21 stl_35">VTC &nbsp;</span></div>
					<div style="position:absolute; top:92.9344em; left:37.9769em;"><span class="stl_20 stl_21 stl_35">SCTV &nbsp;</span></div>
					<div style="position:absolute; top:101.0178em; left:37.9769em;"><span class="stl_20 stl_21 stl_35">HTV &nbsp;</span></div>
					<div style="position:absolute; top:60.6011em; left:48.6433em;"><span class="stl_20 stl_21 stl_35">State &nbsp;</span></div>
					<div style="position:absolute; top:68.6844em; left:48.6433em;"><span class="stl_20 stl_21 stl_35">State &nbsp;</span></div>
					<div style="position:absolute; top:76.7678em; left:48.6433em;"><span class="stl_20 stl_21 stl_35">State &nbsp;</span></div>
					<div style="position:absolute; top:84.8511em; left:48.6433em;"><span class="stl_20 stl_21 stl_35">State &nbsp;</span></div>
					<div style="position:absolute; top:92.9344em; left:48.6433em;"><span class="stl_20 stl_21 stl_35">State &nbsp;</span></div>
					<div style="position:absolute; top:101.0178em; left:48.6433em;"><span class="stl_20 stl_21 stl_35">State &nbsp;</span></div>
					<div style="position:absolute; top:109.1029em; left:48.6433em;"><span class="stl_20 stl_21 stl_35">State &nbsp;</span></div>
					<div style="position:absolute; top:60.6011em; left:57.1389em;"><span class="stl_20 stl_21 stl_35">News, &nbsp;</span></div>
					<div style="position:absolute; top:62.7681em; left:57.1389em;"><span class="stl_20 stl_21 stl_35">movies &nbsp;</span></div>
					<div style="position:absolute; top:60.6011em; left:67.9153em;"><span class="stl_20 stl_21 stl_35">Popular &nbsp;</span></div>
					<div style="position:absolute; top:68.6844em; left:67.9153em;"><span class="stl_20 stl_21 stl_35">Popular &nbsp;</span></div>
					<div style="position:absolute; top:76.7678em; left:67.9153em;"><span class="stl_20 stl_21 stl_35">Popular &nbsp;</span></div>
					<div style="position:absolute; top:84.8511em; left:67.9153em;"><span class="stl_20 stl_21 stl_35">Popular &nbsp;</span></div>
					<div style="position:absolute; top:92.9344em; left:67.9153em;"><span class="stl_20 stl_21 stl_35">Popular &nbsp;</span></div>
					<div style="position:absolute; top:101.0178em; left:67.9153em;"><span class="stl_20 stl_21 stl_35">Popular &nbsp;</span></div>
					<div style="position:absolute; top:109.1029em; left:67.9153em;"><span class="stl_20 stl_21 stl_35">Popular &nbsp;</span></div>
					<div style="position:absolute; top:60.6011em; left:77.5586em;"><span class="stl_20 stl_21 stl_35">National &nbsp;</span></div>
					<div style="position:absolute; top:62.7681em; left:77.5586em;"><span class="stl_20 stl_21 stl_35">wide &nbsp;</span></div>
					<div style="position:absolute; top:60.9173em; left:14.5473em;"><span class="stl_20 stl_21 stl_10">4</span></div>
					<div style="position:absolute; top:69.0006em; left:14.5473em;"><span class="stl_20 stl_21 stl_10">5</span></div>
					<div style="position:absolute; top:77.0839em; left:14.5473em;"><span class="stl_20 stl_21 stl_10">6</span></div>
					<div style="position:absolute; top:85.1673em; left:14.5473em;"><span class="stl_20 stl_21 stl_10">7</span></div>
					<div style="position:absolute; top:93.2506em; left:14.5473em;"><span class="stl_20 stl_21 stl_10">8</span></div>
					<div style="position:absolute; top:101.3339em; left:14.5473em;"><span class="stl_20 stl_21 stl_10">9</span></div>
					<div style="position:absolute; top:60.8348em; left:19.3525em;"><span class="stl_36 stl_21 stl_10">http://vtv.vn &nbsp;</span></div>
					<div style="position:absolute; top:68.6844em; left:57.1389em;"><span class="stl_20 stl_21 stl_35">News, &nbsp;</span></div>
					<div style="position:absolute; top:70.8514em; left:57.1389em;"><span class="stl_20 stl_21 stl_35">movies &nbsp;</span></div>
					<div style="position:absolute; top:68.6844em; left:77.5586em;"><span class="stl_20 stl_21 stl_35">National &nbsp;</span></div>
					<div style="position:absolute; top:70.8514em; left:77.5586em;"><span class="stl_20 stl_21 stl_35">wide &nbsp;</span></div>
					<div style="position:absolute; top:68.9181em; left:19.3525em;"><span class="stl_36 stl_21 stl_10">http://vtvgo.vn &nbsp;</span></div>
					<div style="position:absolute; top:76.7678em; left:57.1389em;"><span class="stl_20 stl_21 stl_35">News, &nbsp;</span></div>
					<div style="position:absolute; top:78.9348em; left:57.1389em;"><span class="stl_20 stl_21 stl_35">movies &nbsp;</span></div>
					<div style="position:absolute; top:76.7678em; left:77.5586em;"><span class="stl_20 stl_21 stl_35">National &nbsp;</span></div>
					<div style="position:absolute; top:78.9348em; left:77.5586em;"><span class="stl_20 stl_21 stl_35">wide &nbsp;</span></div>
					<div style="position:absolute; top:77.0014em; left:19.3525em;"><span class="stl_36 stl_21 stl_10">https://www.vtvgiai- &nbsp;</span></div>
					<div style="position:absolute; top:79.1673em; left:19.3529em;"><span class="stl_36 stl_21 stl_10">tri.vn &nbsp;</span></div>
					<div style="position:absolute; top:84.8511em; left:57.1389em;"><span class="stl_20 stl_21 stl_35">News, &nbsp;</span></div>
					<div style="position:absolute; top:87.0181em; left:57.1389em;"><span class="stl_20 stl_21 stl_35">movies &nbsp;</span></div>
					<div style="position:absolute; top:84.8511em; left:77.5586em;"><span class="stl_20 stl_21 stl_35">National &nbsp;</span></div>
					<div style="position:absolute; top:87.0181em; left:77.5586em;"><span class="stl_20 stl_21 stl_35">wide &nbsp;</span></div>
					<div style="position:absolute; top:85.0848em; left:19.3525em;"><span class="stl_36 stl_21 stl_10">https://vtc.gov.vn &nbsp;</span></div>
					<div style="position:absolute; top:93.1681em; left:19.3525em;"><span class="stl_36 stl_21 stl_10">https://tv24.vn &nbsp;</span></div>
					<div style="position:absolute; top:92.9344em; left:57.1389em;"><span class="stl_20 stl_21 stl_35">News, &nbsp;</span></div>
					<div style="position:absolute; top:95.1014em; left:57.1389em;"><span class="stl_20 stl_21 stl_35">movies &nbsp;</span></div>
					<div style="position:absolute; top:92.9344em; left:77.5586em;"><span class="stl_20 stl_21 stl_35">Southern &nbsp;</span></div>
					<div style="position:absolute; top:101.0178em; left:57.1389em;"><span class="stl_20 stl_21 stl_35">News, &nbsp;</span></div>
					<div style="position:absolute; top:103.1848em; left:57.1389em;"><span class="stl_20 stl_21 stl_35">movies &nbsp;</span></div>
					<div style="position:absolute; top:101.0178em; left:77.5586em;"><span class="stl_20 stl_21 stl_35" style="word-spacing:0em;">HCMC and &nbsp;</span></div>
					<div style="position:absolute; top:103.1848em; left:77.5586em;"><span class="stl_20 stl_21 stl_35">Southern &nbsp;</span></div>
					<div style="position:absolute; top:101.2514em; left:19.3525em;"><span class="stl_36 stl_21 stl_10">http://hplus.com.vn &nbsp;</span></div>
					<div style="position:absolute; top:109.3348em; left:19.3528em;"><span class="stl_36 stl_21 stl_10">http://quochoitv.vn &nbsp;</span></div>
					<div style="position:absolute; top:108.5181em; left:37.9769em;"><span class="stl_20 stl_21 stl_35">National &nbsp;</span></div>
					<div style="position:absolute; top:110.6851em; left:37.9769em;"><span class="stl_20 stl_21 stl_35">Assembly &nbsp;</span></div>
					<div style="position:absolute; top:112.8521em; left:37.9769em;"><span class="stl_20 stl_21 stl_35">TV &nbsp;</span></div>
					<div style="position:absolute; top:109.1011em; left:57.1389em;"><span class="stl_20 stl_21 stl_35">News, &nbsp;</span></div>
					<div style="position:absolute; top:111.2681em; left:57.1389em;"><span class="stl_20 stl_21 stl_35">movies &nbsp;</span></div>
					<div style="position:absolute; top:109.1029em; left:77.5586em;"><span class="stl_20 stl_21 stl_35">Northern &nbsp;</span></div>
					<div style="position:absolute; top:109.4173em; left:14.214em;"><span class="stl_20 stl_21 stl_10">1</span></div>
					<div style="position:absolute; top:109.4173em; left:15.1545em;"><span class="stl_20 stl_21 stl_10">0</span></div>
					<div style="position:absolute; top:122.4428em; left:68.5116em;"><span class="stl_24 stl_25 stl_30" style="word-spacing:-0.0118em;">KICC E-JOURNAL - Vol 4 &nbsp;</span></div>
					<div style="position:absolute; top:122.3082em; left:86.644em;"><span class="stl_27 stl_28 stl_10">0</span></div>
					<div style="position:absolute; top:122.3082em; left:87.6634em;"><span class="stl_27 stl_28 stl_10">5</span></div>
				</div>
			</div>
		</div>
		<div class="stl_01">
			<div class="stl_02">
				<object data="http://35.240.140.159/images/201811/img_13.svg" type="image/svg+xml" class="stl_03" style="position:absolute; width:98em; height:129.3333em;">
					<embed src="http://35.240.140.159/images/201811/img_13.svg" type="image/svg+xml" class="stl_03" />
				</object>
			</div>
			<div class="layer">
				<div class="stl_04 stl_05">
					<div style="position:absolute; top:11.36em; left:48.7342em;"><span class="stl_33 stl_34 stl_10" style="word-spacing:0em;">Kind of &nbsp;</span></div>
					<div style="position:absolute; top:13.3603em; left:48.9267em;"><span class="stl_33 stl_34 stl_10">Owner &nbsp;</span></div>
					<div style="position:absolute; top:11.36em; left:68.546em;"><span class="stl_33 stl_34 stl_10">Target &nbsp;</span></div>
					<div style="position:absolute; top:13.3603em; left:67.615em;"><span class="stl_33 stl_34 stl_10">Audience &nbsp;</span></div>
					<div style="position:absolute; top:11.36em; left:79.3942em;"><span class="stl_33 stl_34 stl_10">Target &nbsp;</span></div>
					<div style="position:absolute; top:13.3603em; left:78.9585em;"><span class="stl_33 stl_34 stl_10">location &nbsp;</span></div>
					<div style="position:absolute; top:12.3647em; left:13.9452em;"><span class="stl_33 stl_34 stl_10">No. &nbsp;</span></div>
					<div style="position:absolute; top:12.3593em; left:25.1722em;"><span class="stl_33 stl_34 stl_10">URLs &nbsp;</span></div>
					<div style="position:absolute; top:12.3593em; left:39.377em;"><span class="stl_33 stl_34 stl_10">Owner &nbsp;</span></div>
					<div style="position:absolute; top:12.3593em; left:57.7047em;"><span class="stl_33 stl_34 stl_10">Content &nbsp;</span></div>
					<div style="position:absolute; top:18.8204em; left:37.8372em;"><span class="stl_20 stl_21 stl_35">Ocean &nbsp;</span></div>
					<div style="position:absolute; top:20.9874em; left:37.8372em;"><span class="stl_20 stl_21 stl_35">Digital &nbsp;</span></div>
					<div style="position:absolute; top:18.9048em; left:48.7547em;"><span class="stl_20 stl_21 stl_35">Private &nbsp;</span></div>
					<div style="position:absolute; top:18.9029em; left:57.2485em;"><span class="stl_20 stl_21 stl_35">Movies &nbsp;</span></div>
					<div style="position:absolute; top:18.9048em; left:68.0285em;"><span class="stl_20 stl_21 stl_35">Youth &nbsp;</span></div>
					<div style="position:absolute; top:18.9048em; left:77.6719em;"><span class="stl_20 stl_21 stl_35">National &nbsp;</span></div>
					<div style="position:absolute; top:21.0718em; left:77.6719em;"><span class="stl_20 stl_21 stl_35">wide &nbsp;</span></div>
					<div style="position:absolute; top:19.1546em; left:14.1569em;"><span class="stl_20 stl_21 stl_10">1</span></div>
					<div style="position:absolute; top:19.1546em; left:15.0974em;"><span class="stl_20 stl_21 stl_10">1</span></div>
					<div style="position:absolute; top:19.1359em; left:19.4625em;"><span class="stl_36 stl_21 stl_10">http://hdonline.vn &nbsp;</span></div>
					<div style="position:absolute; top:23.1545em; left:37.8372em;"><span class="stl_20 stl_21 stl_35">Service &nbsp;</span></div>
					<div style="position:absolute; top:25.3215em; left:37.8372em;"><span class="stl_20 stl_21 stl_35">Company &nbsp;</span></div>
					<div style="position:absolute; top:29.973em; left:37.8372em;"><span class="stl_20 stl_21 stl_35" style="word-spacing:0em;">BHD Media</span><span class="stl_20 stl_21 stl_35" style="word-spacing:1.186em;"> Private &nbsp;</span></div>
					<div style="position:absolute; top:29.973em; left:57.2485em;"><span class="stl_20 stl_21 stl_35">Movies &nbsp;</span></div>
					<div style="position:absolute; top:37.0291em; left:57.2485em;"><span class="stl_20 stl_21 stl_35">Movies &nbsp;</span></div>
					<div style="position:absolute; top:29.973em; left:68.0285em;"><span class="stl_20 stl_21 stl_35">Youth &nbsp;</span></div>
					<div style="position:absolute; top:37.0309em; left:68.0285em;"><span class="stl_20 stl_21 stl_35">Youth &nbsp;</span></div>
					<div style="position:absolute; top:29.973em; left:77.6719em;"><span class="stl_20 stl_21 stl_35">National &nbsp;</span></div>
					<div style="position:absolute; top:32.14em; left:77.6719em;"><span class="stl_20 stl_21 stl_35">wide &nbsp;</span></div>
					<div style="position:absolute; top:30.2058em; left:19.4625em;"><span class="stl_36 stl_21 stl_10">http://danet.vn/go &nbsp;</span></div>
					<div style="position:absolute; top:37.2619em; left:19.4625em;"><span class="stl_36 stl_21 stl_10">http://&#x1F;mplus.vn/ &nbsp;</span></div>
					<div style="position:absolute; top:30.5304em; left:14.1569em;"><span class="stl_20 stl_21 stl_10">1</span></div>
					<div style="position:absolute; top:37.2807em; left:14.1569em;"><span class="stl_20 stl_21 stl_10">1</span></div>
					<div style="position:absolute; top:30.5304em; left:15.0974em;"><span class="stl_20 stl_21 stl_10">2</span></div>
					<div style="position:absolute; top:37.2807em; left:15.0974em;"><span class="stl_20 stl_21 stl_10">3</span></div>
					<div style="position:absolute; top:36.2792em; left:37.8372em;"><span class="stl_20 stl_21 stl_35" style="word-spacing:0em;">Galaxy – &nbsp;</span></div>
					<div style="position:absolute; top:36.5304em; left:48.7547em;"><span class="stl_20 stl_21 stl_35">Private &nbsp;</span></div>
					<div style="position:absolute; top:37.0309em; left:77.6719em;"><span class="stl_20 stl_21 stl_35">National &nbsp;</span></div>
					<div style="position:absolute; top:39.1979em; left:77.6719em;"><span class="stl_20 stl_21 stl_35">wide &nbsp;</span></div>
					<div style="position:absolute; top:38.4463em; left:37.8372em;"><span class="stl_20 stl_21 stl_35" style="word-spacing:0em;">Thien Ngan &nbsp;</span></div>
					<div style="position:absolute; top:40.6133em; left:37.8372em;"><span class="stl_20 stl_21 stl_35">Company &nbsp;</span></div>
					<div style="position:absolute; top:45.1124em; left:38.0865em;"><span class="stl_20 stl_21 stl_35" style="word-spacing:0em;">Bach Minh</span><span class="stl_20 stl_21 stl_35" style="word-spacing:1.319em;"> Private &nbsp;</span></div>
					<div style="position:absolute; top:47.2794em; left:38.0865em;"><span class="stl_20 stl_21 stl_35">JSC &nbsp;</span></div>
					<div style="position:absolute; top:45.1124em; left:57.2485em;"><span class="stl_20 stl_21 stl_35">Movies &nbsp;</span></div>
					<div style="position:absolute; top:53.1958em; left:57.2485em;"><span class="stl_20 stl_21 stl_35">Movies &nbsp;</span></div>
					<div style="position:absolute; top:45.1124em; left:68.0267em;"><span class="stl_20 stl_21 stl_35">Youth &nbsp;</span></div>
					<div style="position:absolute; top:53.1976em; left:68.0267em;"><span class="stl_20 stl_21 stl_35">Youth &nbsp;</span></div>
					<div style="position:absolute; top:45.1124em; left:77.67em;"><span class="stl_20 stl_21 stl_35">National &nbsp;</span></div>
					<div style="position:absolute; top:47.2794em; left:77.67em;"><span class="stl_20 stl_21 stl_35">wide &nbsp;</span></div>
					<div style="position:absolute; top:45.3639em; left:14.1569em;"><span class="stl_20 stl_21 stl_10">1</span></div>
					<div style="position:absolute; top:53.4473em; left:14.1569em;"><span class="stl_20 stl_21 stl_10">1</span></div>
					<div style="position:absolute; top:45.3639em; left:15.0974em;"><span class="stl_20 stl_21 stl_10">4</span></div>
					<div style="position:absolute; top:53.4473em; left:15.0974em;"><span class="stl_20 stl_21 stl_10">5</span></div>
					<div style="position:absolute; top:45.3453em; left:19.4625em;"><span class="stl_36 stl_21 stl_10">http://cliptv.vn &nbsp;</span></div>
					<div style="position:absolute; top:52.9464em; left:38.0865em;"><span class="stl_20 stl_21 stl_35" style="word-spacing:0em;">I&#x1A;ix Viet &nbsp;</span></div>
					<div style="position:absolute; top:55.1134em; left:38.0865em;"><span class="stl_20 stl_21 stl_35">Nam &nbsp;</span></div>
					<div style="position:absolute; top:53.1976em; left:48.7529em;"><span class="stl_20 stl_21 stl_35">State &nbsp;</span></div>
					<div style="position:absolute; top:53.1976em; left:77.67em;"><span class="stl_20 stl_21 stl_35">National &nbsp;</span></div>
					<div style="position:absolute; top:55.3646em; left:77.67em;"><span class="stl_20 stl_21 stl_35">wide &nbsp;</span></div>
					<div style="position:absolute; top:53.429em; left:19.4626em;"><span class="stl_36 stl_21 stl_10">https://piay.i&#x1A;ix.com &nbsp;</span></div>
					<div style="position:absolute; top:57.2804em; left:38.0865em;"><span class="stl_20 stl_21 stl_35">Company &nbsp;</span></div>
					<div style="position:absolute; top:59.4474em; left:38.0865em;"><span class="stl_20 stl_21 stl_35">Limited &nbsp;</span></div>
					<div style="position:absolute; top:69.1196em; left:12.7566em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.195em;">Beside the legally service listed above, there were kind of illegal and copy right infringement &nbsp;</span></div>
					<div style="position:absolute; top:71.2866em; left:12.7566em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.067em;">websites and URLs that were operated by people and provided free services for user via internet. &nbsp;</span></div>
					<div style="position:absolute; top:73.4536em; left:12.7566em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.008em;">Recent years, local authority agency had actively investigated and stopped accessing to this kind of &nbsp;</span></div>
					<div style="position:absolute; top:75.6206em; left:12.7566em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.038em;">illegal website. But there is a practice that after being stopped at one URLs, the operator will soon &nbsp;</span></div>
					<div style="position:absolute; top:77.7876em; left:12.7566em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.064em;">moves to another domain name and continues to provide illegal service.</span><span class="stl_20 stl_21 stl_10" style="word-spacing:0.616em;"> Below</span><span class="stl_20 stl_21 stl_10" style="word-spacing:0.064em;"> list shows</span><span class="stl_20 stl_21 stl_10" style="word-spacing:0.064em;"> some &nbsp;</span></div>
					<div style="position:absolute; top:79.9546em; left:12.7566em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">URLs of this kind of service: &nbsp;</span></div>
					<div style="position:absolute; top:82.1216em; left:12.7566em;"><span class="stl_20 stl_21 stl_10">-</span></div>
					<div style="position:absolute; top:84.2886em; left:12.7566em;"><span class="stl_20 stl_21 stl_10">-</span></div>
					<div style="position:absolute; top:86.4556em; left:12.7566em;"><span class="stl_20 stl_21 stl_10">-</span></div>
					<div style="position:absolute; top:82.1216em; left:15.0171em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">Xoilac.TV (stopped already) &nbsp;</span></div>
					<div style="position:absolute; top:84.2886em; left:15.0171em;"><span class="stl_20 stl_21 stl_10">Banhkhuc.TV &nbsp;</span></div>
					<div style="position:absolute; top:86.4556em; left:15.0171em;"><span class="stl_20 stl_21 stl_10">HayhayTV.com &nbsp;</span></div>
					<div style="position:absolute; top:92.4677em; left:12.5151em;"><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;">Policy maker and policy for OTT TV services in Viet Nam &nbsp;</span></div>
					<div style="position:absolute; top:98.9186em; left:12.7566em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.026em;">Authority of broadcasting and electronic information (ABEI) which is an institution belongs to MIC is &nbsp;</span></div>
					<div style="position:absolute; top:101.0856em; left:12.7566em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.276em;">the local regulator on the &#x1F;eld of television. The most relevance legal document is Decree &nbsp;</span></div>
					<div style="position:absolute; top:103.2526em; left:12.7566em;"><span class="stl_20 stl_21 stl_10">0</span></div>
					<div style="position:absolute; top:105.4196em; left:12.7566em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.104em;">document is quite outdate when no mention any word about OTT Television. It is on amending &nbsp;</span></div>
					<div style="position:absolute; top:107.5866em; left:12.7566em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">process to cover OTT TV service in the scope of adjustment. &nbsp;</span></div>
					<div style="position:absolute; top:103.2526em; left:13.6971em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.253em;">6/2016/ND-CP on management, provision and use of radio and television services. But this &nbsp;</span></div>
					<div style="position:absolute; top:109.7536em; left:12.7566em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.012em;">That means until now, Vietnam Law has not yet updated regulation on OTT Service in general. OTT &nbsp;</span></div>
					<div style="position:absolute; top:111.9206em; left:12.7566em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.042em;">TV service still be classi&#x1F;ed to Digital Content Services. Digital content cross border provider must &nbsp;</span></div>
					<div style="position:absolute; top:114.0876em; left:12.7566em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.019em;">open local o&#x1D;ce in Viet Nam to provide service to Vietnamese user. By this condition, Net&#x1A;ix is still &nbsp;</span></div>
					<div style="position:absolute; top:116.2546em; left:12.7566em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">illegal operation in Viet Nam while I&#x1A;ix did open a local o&#x1D;ce and got full license in 2017. &nbsp;</span></div>
					<div style="position:absolute; top:122.4428em; left:68.6213em;"><span class="stl_24 stl_25 stl_30" style="word-spacing:-0.0118em;">KICC E-JOURNAL - Vol 4 &nbsp;</span></div>
					<div style="position:absolute; top:122.3082em; left:86.7537em;"><span class="stl_27 stl_28 stl_10">0</span></div>
					<div style="position:absolute; top:122.3082em; left:87.773em;"><span class="stl_27 stl_28 stl_10">6</span></div>
				</div>
			</div>
		</div>
		<div class="stl_01">
			<div class="stl_02">
				<object data="http://35.240.140.159/images/201811/img_14.svg" type="image/svg+xml" class="stl_03" style="position:absolute; width:98em; height:129.3333em;">
					<embed src="http://35.240.140.159/images/201811/img_14.svg" type="image/svg+xml" class="stl_03" />
				</object>
			</div>
			<div class="layer">
				<div class="stl_04 stl_05">
					<div style="position:absolute; top:99.8541em; left:14.5766em;"><span class="stl_37 stl_07 stl_11" style="word-spacing:0.1832em;">LOCAL ICT MARKET HIGHLIGHTS &nbsp;</span></div>
				</div>
			</div>
		</div>
		<div class="stl_01">
			<div class="stl_02">
				<object data="http://35.240.140.159/images/201811/img_17.svg" type="image/svg+xml" class="stl_03" style="position:absolute; width:98em; height:129.3333em;">
					<embed src="http://35.240.140.159/images/201811/img_17.svg" type="image/svg+xml" class="stl_03" />
				</object>
			</div>
			<div class="layer">
				<div class="stl_04 stl_05">
					<div style="position:absolute; top:6.5987em; left:9.2565em;"><span class="stl_18 stl_19 stl_10">1</span></div>
					<div style="position:absolute; top:6.5987em; left:10.5345em;"><span class="stl_18 stl_19 stl_10" style="word-spacing:0.254em;">. Viet</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> Nam PM chairs &#x1F;rst</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> meeting</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> of</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> national</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> e-government</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> committee &nbsp;</span></div>
					<div style="position:absolute; top:12.7em; left:12.4064em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.463em;">Prime Minister Nguyen Xuan Phuc &nbsp;</span></div>
					<div style="position:absolute; top:14.867em; left:12.4064em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.634em;">chaired the &#x1F;rst meeting of the &nbsp;</span></div>
					<div style="position:absolute; top:17.034em; left:12.4064em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.107em;">National E-Government Committee in &nbsp;</span></div>
					<div style="position:absolute; top:19.201em; left:12.4064em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">Hanoi on September 20. &nbsp;</span></div>
					<div style="position:absolute; top:21.368em; left:12.4064em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.018em;">Speaking at the meeting, PM Phuc said &nbsp;</span></div>
					<div style="position:absolute; top:23.535em; left:12.4064em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.154em;">Vietnam is still at an average level in &nbsp;</span></div>
					<div style="position:absolute; top:25.702em; left:12.4064em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.164em;">e-government rankings both globally &nbsp;</span></div>
					<div style="position:absolute; top:27.8691em; left:12.4064em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.024em;">and regionally, so the country needs to &nbsp;</span></div>
					<div style="position:absolute; top:30.0361em; left:12.4064em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">show stronger resolve in the work. &nbsp;</span></div>
					<div style="position:absolute; top:33.5121em; left:12.4064em;"><span class="stl_20 stl_21 stl_38" style="word-spacing:0.075em;">In addition to the debut of the committee, &nbsp;</span></div>
					<div style="position:absolute; top:35.6791em; left:12.4064em;"><span class="stl_20 stl_21 stl_38" style="word-spacing:0.049em;">the presence of four major IT companies in &nbsp;</span></div>
					<div style="position:absolute; top:37.8461em; left:12.4064em;"><span class="stl_20 stl_21 stl_39" style="word-spacing:0.296em;">the national e-government committee &nbsp;</span></div>
					<div style="position:absolute; top:40.0131em; left:12.4064em;"><span class="stl_20 stl_21 stl_40">demonstratesthepublic-privatepartnership &nbsp;</span></div>
					<div style="position:absolute; top:42.1801em; left:12.4064em;"><span class="stl_20 stl_21 stl_41" style="word-spacing:0.0119em;">in the &#x1F;eld, he noted, adding</span><span class="stl_20 stl_21 stl_41" style="word-spacing:0.1729em;"> that the participation of the PM and a Deputy PM in the</span><span class="stl_20 stl_21 stl_41" style="word-spacing:0.1729em;"> committee &nbsp;</span></div>
					<div style="position:absolute; top:44.3471em; left:12.4064em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">re&#x1A;ects the high political determination to successfully build an e-government. &nbsp;</span></div>
					<div style="position:absolute; top:47.3464em; left:12.4064em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.313em;">The Government leader urged a more rapid building of national databases on population, &nbsp;</span></div>
					<div style="position:absolute; top:49.5134em; left:12.4064em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.067em;">insurance, &#x1F;nance and land, with &#x1F;rst priority given to the population database. The committee’s &nbsp;</span></div>
					<div style="position:absolute; top:51.6804em; left:12.4064em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.203em;">members focused their attention on solutions to remove obstacles in e-government building, &nbsp;</span></div>
					<div style="position:absolute; top:53.8474em; left:12.4064em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.033em;">speci&#x1F;c targets for each period, and the committee’s working plan to the end of this year. Also at the &nbsp;</span></div>
					<div style="position:absolute; top:56.0144em; left:12.4064em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.489em;">meeting, PM Nguyen Xuan Phuc witnessed the signing of cooperation agreements on &nbsp;</span></div>
					<div style="position:absolute; top:58.1814em; left:12.4064em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.003em;">e-government building between the Government O&#x1D;ce and the Australian Department of Foreign &nbsp;</span></div>
					<div style="position:absolute; top:60.3484em; left:12.4064em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.015em;">A&#x1E;airs and Trade and the World Bank in Vietnam, along with regulations for coordination between &nbsp;</span></div>
					<div style="position:absolute; top:62.5154em; left:12.4064em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.019em;">the Government O&#x1D;ce and the Ministry of Information and Communications and the Government &nbsp;</span></div>
					<div style="position:absolute; top:64.6824em; left:12.4064em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">Information Security Commission &nbsp;</span></div>
					<div style="position:absolute; top:70.0192em; left:9.2565em;"><span class="stl_18 stl_19 stl_10">2</span></div>
					<div style="position:absolute; top:70.0192em; left:10.5345em;"><span class="stl_18 stl_19 stl_10" style="word-spacing:0.159em;">. MIC</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> Acting</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> Minister</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> Nguyen</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> Manh Hung</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> welcomes President</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> of &nbsp;</span></div>
					<div style="position:absolute; top:73.6192em; left:12.1185em;"><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;">Dasan Zhone Solutions &nbsp;</span></div>
					<div style="position:absolute; top:79.4143em; left:12.6352em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.124em;">On September 19, at the headquarters of MIC, &nbsp;</span></div>
					<div style="position:absolute; top:81.5813em; left:12.6352em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.204em;">Acting Minister Nguyen Manh Hung met and &nbsp;</span></div>
					<div style="position:absolute; top:83.7483em; left:12.6352em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.04em;">worked with Mr. Yung Kim, President and CEO of &nbsp;</span></div>
					<div style="position:absolute; top:85.9153em; left:12.6352em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.302em;">Dasan Zhone Solutions. At the meeting, Mr. &nbsp;</span></div>
					<div style="position:absolute; top:88.0823em; left:12.6352em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.284em;">Yung Kim expressed his desire to cooperate &nbsp;</span></div>
					<div style="position:absolute; top:90.2493em; left:12.6352em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.651em;">with Vietnamese partners to design and &nbsp;</span></div>
					<div style="position:absolute; top:92.4163em; left:12.6352em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.452em;">manufacture ONT chipsets in Vietnam and &nbsp;</span></div>
					<div style="position:absolute; top:94.5833em; left:12.6352em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.794em;">export to the world market. Dasan is &nbsp;</span></div>
					<div style="position:absolute; top:96.7503em; left:12.6352em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.194em;">collaborating with the Vietnam-Korea Science &nbsp;</span></div>
					<div style="position:absolute; top:98.9173em; left:12.6352em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.212em;">and Technology Institute (VKIST) to carry out &nbsp;</span></div>
					<div style="position:absolute; top:101.0843em; left:12.6352em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.072em;">initial steps of designing the chipset. However, &nbsp;</span></div>
					<div style="position:absolute; top:103.2513em; left:12.6352em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.159em;">the implementation is facing some di&#x1D;culties &nbsp;</span></div>
					<div style="position:absolute; top:105.4183em; left:12.6352em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.082em;">such as: shortage of human resources. Dasan wants to cooperate with telecom operators such as &nbsp;</span></div>
					<div style="position:absolute; top:107.5853em; left:12.6352em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">VNPT and Viettel to implement this project. &nbsp;</span></div>
					<div style="position:absolute; top:110.5846em; left:12.9615em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.034em;">Acting Minister Nguyen Manh Hung said that MIC fully supported this project. The Ministry will chair &nbsp;</span></div>
					<div style="position:absolute; top:112.7516em; left:12.6352em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.097em;">and invite Viettel and VNPT to join. On human resources, Acting Minister said that the Posts and &nbsp;</span></div>
					<div style="position:absolute; top:114.9186em; left:12.6352em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.18em;">Telecommunications Technology Institute (under Ministry of Information and Communications) &nbsp;</span></div>
					<div style="position:absolute; top:117.0856em; left:12.6352em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">would consider to open chip programming courses to support the needs of technology companies. &nbsp;</span></div>
					<div style="position:absolute; top:122.402em; left:68.634em;"><span class="stl_24 stl_25 stl_30" style="word-spacing:-0.0118em;">KICC E-JOURNAL - Vol 4 &nbsp;</span></div>
					<div style="position:absolute; top:122.2674em; left:86.7664em;"><span class="stl_27 stl_28 stl_10">0</span></div>
					<div style="position:absolute; top:122.2674em; left:87.7857em;"><span class="stl_27 stl_28 stl_10">7</span></div>
				</div>
			</div>
		</div>
		<div class="stl_01">
			<div class="stl_02">
				<object data="http://35.240.140.159/images/201811/img_18.svg" type="image/svg+xml" class="stl_03" style="position:absolute; width:98em; height:129.3333em;">
					<embed src="http://35.240.140.159/images/201811/images/201811/img_18.svg" type="image/svg+xml" class="stl_03" />
				</object>
			</div>
			<div class="layer">
				<div class="stl_04 stl_05">
					<div style="position:absolute; top:10.9809em; left:9.0377em;"><span class="stl_18 stl_19 stl_10">3</span></div>
					<div style="position:absolute; top:10.9809em; left:10.3157em;"><span class="stl_18 stl_19 stl_10" style="word-spacing:0.254em;">. The</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> Smart IoT</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> Vietnam</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> 2018</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> Conference</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> &amp;</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> Exhibition &nbsp;</span></div>
					<div style="position:absolute; top:17.9682em; left:12.2991em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.033em;">The Smart IoT Vietnam 2018 Conference &amp; Exhibition will take place at Ho Chi Minh City from 23 – &nbsp;</span></div>
					<div style="position:absolute; top:20.1352em; left:12.2991em;"><span class="stl_20 stl_21 stl_10">2</span></div>
					<div style="position:absolute; top:20.1352em; left:13.2396em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.149em;">4 October 2018. Co-hosted by Central Economic Commission and Ministry of Information and &nbsp;</span></div>
					<div style="position:absolute; top:22.3022em; left:12.2991em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.148em;">Communications, co-organized by Vietnam Internet Association and IEC Group, Smart IoT 2018 &nbsp;</span></div>
					<div style="position:absolute; top:24.4692em; left:12.2991em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.387em;">Conference &amp; Exhibition will feature the theme “REALIZING THE POTENTIAL OF IOT AND &nbsp;</span></div>
					<div style="position:absolute; top:26.6362em; left:12.2991em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">DISCOVERING THE VIETNAM’S IOT MARKET”. &nbsp;</span></div>
					<div style="position:absolute; top:29.6356em; left:12.2991em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.066em;">With 30+ international and local speakers sharing their unparalleled industry knowledge and real &nbsp;</span></div>
					<div style="position:absolute; top:31.8026em; left:12.2991em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.059em;">case studies, the event brings in an engaging platform for case study presentations, best practice &nbsp;</span></div>
					<div style="position:absolute; top:33.9696em; left:12.2991em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.012em;">sharing and in-depth discussion about the latest IoT trends as well as how Vietnamese Government &nbsp;</span></div>
					<div style="position:absolute; top:36.1366em; left:12.2991em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">agencies and enterprises can take the advantage of IoT technologies. &nbsp;</span></div>
					<div style="position:absolute; top:39.1359em; left:12.2991em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.157em;">The Smart IoT Exhibition is set to showcase cutting-edge technologies from global leading IoT &nbsp;</span></div>
					<div style="position:absolute; top:41.3029em; left:12.2991em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.109em;">vendors across industries: Manufacturing, Telco, Smart City, Smart Building &amp; Home, Energy and &nbsp;</span></div>
					<div style="position:absolute; top:43.4699em; left:12.2991em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.107em;">Utilities, Transportation &amp; Logistics, Agriculture, Healthcare, Banking &amp; Finance,… Suggest Korea &nbsp;</span></div>
					<div style="position:absolute; top:45.6369em; left:12.2991em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">IOT Company to attend this event. More detail is provided at </span><span class="stl_36 stl_21 stl_10" style="word-spacing:0em;">http://smartiot.vn/ &nbsp;</span></div>
					<div style="position:absolute; top:53.0856em; left:9.0377em;"><span class="stl_18 stl_19 stl_10">4</span></div>
					<div style="position:absolute; top:53.0856em; left:10.3157em;"><span class="stl_18 stl_19 stl_10" style="word-spacing:0.254em;">. Vietnamese</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> mobile</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> carriers</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> roll</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> out new</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> pre&#x1F;xes &nbsp;</span></div>
					<div style="position:absolute; top:59.9325em; left:12.2991em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.015em;">Mobile carriers in Vietnam have started to shorten their 11-digit mobile phone numbers to 10 digits &nbsp;</span></div>
					<div style="position:absolute; top:62.0995em; left:12.2991em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.003em;">by replacing some of the current pre&#x1F;xes with new numbers in a move to standardise the length of &nbsp;</span></div>
					<div style="position:absolute; top:64.2665em; left:12.2991em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">all mobile numbers. Following table shows time table and detail of the replacement. &nbsp;</span></div>
					<div style="position:absolute; top:70.3187em; left:34.7436em;"><span class="stl_42 stl_43 stl_10">Old &nbsp;</span></div>
					<div style="position:absolute; top:72.0692em; left:34.7421em;"><span class="stl_42 stl_43 stl_10">Net &nbsp;</span></div>
					<div style="position:absolute; top:73.8197em; left:34.3671em;"><span class="stl_42 stl_43 stl_10">Code &nbsp;</span></div>
					<div style="position:absolute; top:70.3202em; left:40.9431em;"><span class="stl_42 stl_43 stl_10">New &nbsp;</span></div>
					<div style="position:absolute; top:72.0707em; left:41.2416em;"><span class="stl_42 stl_43 stl_10">Net &nbsp;</span></div>
					<div style="position:absolute; top:73.8212em; left:40.8666em;"><span class="stl_42 stl_43 stl_10">Code &nbsp;</span></div>
					<div style="position:absolute; top:70.9432em; left:63.3776em;"><span class="stl_42 stl_43 stl_10">Dual &nbsp;</span></div>
					<div style="position:absolute; top:70.9437em; left:70.7966em;"><span class="stl_42 stl_43 stl_10" style="word-spacing:1.2768em;">Reminding Expiration &nbsp;</span></div>
					<div style="position:absolute; top:72.6942em; left:72.7061em;"><span class="stl_42 stl_43 stl_10" style="word-spacing:3.6357em;">time</span><sup><span class="stl_44 stl_43 stl_08" style="word-spacing:6.2363em;">4 </span></sup><span class="stl_42 stl_43 stl_10" style="word-spacing:3.6357em;">Date</span><sup><span class="stl_44 stl_43 stl_08" style="word-spacing:6.2363em;">5 &nbsp;</span></sup></div>
					<div style="position:absolute; top:71.1937em; left:22.3061em;"><span class="stl_42 stl_43 stl_10">Mobile &nbsp;</span></div>
					<div style="position:absolute; top:72.9442em; left:21.7601em;"><span class="stl_42 stl_43 stl_10">Operator &nbsp;</span></div>
					<div style="position:absolute; top:72.0687em; left:13.5399em;"><span class="stl_42 stl_43 stl_10">No. &nbsp;</span></div>
					<div style="position:absolute; top:71.9437em; left:47.8886em;"><span class="stl_42 stl_43 stl_10" style="word-spacing:0em;">Switching Date &nbsp;</span></div>
					<div style="position:absolute; top:72.6937em; left:61.8851em;"><span class="stl_42 stl_43 stl_10" style="word-spacing:0em;">dial time</span><sup><span class="stl_44 stl_43 stl_10" style="word-spacing:-0.0001em;">3 &nbsp;</span></sup></div>
					<div style="position:absolute; top:77.1656em; left:34.1744em;"><span class="stl_20 stl_21 stl_10">0</span></div>
					<div style="position:absolute; top:80.4198em; left:34.1744em;"><span class="stl_20 stl_21 stl_10">0</span></div>
					<div style="position:absolute; top:83.674em; left:34.1744em;"><span class="stl_20 stl_21 stl_10">0</span></div>
					<div style="position:absolute; top:86.9281em; left:34.1744em;"><span class="stl_20 stl_21 stl_10">0</span></div>
					<div style="position:absolute; top:90.1823em; left:34.1744em;"><span class="stl_20 stl_21 stl_10">0</span></div>
					<div style="position:absolute; top:93.4365em; left:34.1744em;"><span class="stl_20 stl_21 stl_10">0</span></div>
					<div style="position:absolute; top:96.6906em; left:34.1744em;"><span class="stl_20 stl_21 stl_10">0</span></div>
					<div style="position:absolute; top:99.9448em; left:34.1744em;"><span class="stl_20 stl_21 stl_10">0</span></div>
					<div style="position:absolute; top:77.1656em; left:35.1149em;"><span class="stl_20 stl_21 stl_10">162 &nbsp;</span></div>
					<div style="position:absolute; top:80.4198em; left:35.1149em;"><span class="stl_20 stl_21 stl_10">163 &nbsp;</span></div>
					<div style="position:absolute; top:83.674em; left:35.1149em;"><span class="stl_20 stl_21 stl_10">164 &nbsp;</span></div>
					<div style="position:absolute; top:86.9281em; left:35.1149em;"><span class="stl_20 stl_21 stl_10">165 &nbsp;</span></div>
					<div style="position:absolute; top:90.1823em; left:35.1149em;"><span class="stl_20 stl_21 stl_10">166 &nbsp;</span></div>
					<div style="position:absolute; top:93.4365em; left:35.1149em;"><span class="stl_20 stl_21 stl_10">167 &nbsp;</span></div>
					<div style="position:absolute; top:96.6906em; left:35.1149em;"><span class="stl_20 stl_21 stl_10">168 &nbsp;</span></div>
					<div style="position:absolute; top:99.9448em; left:35.1149em;"><span class="stl_20 stl_21 stl_10">169 &nbsp;</span></div>
					<div style="position:absolute; top:77.1675em; left:41.1447em;"><span class="stl_20 stl_21 stl_10">032 &nbsp;</span></div>
					<div style="position:absolute; top:80.4216em; left:41.1447em;"><span class="stl_20 stl_21 stl_10">033 &nbsp;</span></div>
					<div style="position:absolute; top:83.6758em; left:41.1447em;"><span class="stl_20 stl_21 stl_10">034 &nbsp;</span></div>
					<div style="position:absolute; top:86.93em; left:41.1447em;"><span class="stl_20 stl_21 stl_10">035 &nbsp;</span></div>
					<div style="position:absolute; top:90.1841em; left:41.1447em;"><span class="stl_20 stl_21 stl_10">036 &nbsp;</span></div>
					<div style="position:absolute; top:93.4383em; left:41.1447em;"><span class="stl_20 stl_21 stl_10">037 &nbsp;</span></div>
					<div style="position:absolute; top:96.6925em; left:41.1447em;"><span class="stl_20 stl_21 stl_10">038 &nbsp;</span></div>
					<div style="position:absolute; top:99.9466em; left:41.1447em;"><span class="stl_20 stl_21 stl_10">039 &nbsp;</span></div>
					<div style="position:absolute; top:77.1693em; left:48.5752em;"><span class="stl_20 stl_21 stl_10">07/10/2018 &nbsp;</span></div>
					<div style="position:absolute; top:80.4235em; left:48.5752em;"><span class="stl_20 stl_21 stl_10">05/10/2018 &nbsp;</span></div>
					<div style="position:absolute; top:83.6776em; left:48.5752em;"><span class="stl_20 stl_21 stl_10">03/10/2018 &nbsp;</span></div>
					<div style="position:absolute; top:86.9318em; left:48.5752em;"><span class="stl_20 stl_21 stl_10">25/09/2018 &nbsp;</span></div>
					<div style="position:absolute; top:90.1859em; left:48.5752em;"><span class="stl_20 stl_21 stl_10">23/09/2018 &nbsp;</span></div>
					<div style="position:absolute; top:93.4401em; left:48.5752em;"><span class="stl_20 stl_21 stl_10">19/09/2018 &nbsp;</span></div>
					<div style="position:absolute; top:96.6943em; left:48.5752em;"><span class="stl_20 stl_21 stl_10">17/09/2018 &nbsp;</span></div>
					<div style="position:absolute; top:99.9485em; left:48.5752em;"><span class="stl_20 stl_21 stl_10">15/09/2018 &nbsp;</span></div>
					<div style="position:absolute; top:78.5906em; left:62.0469em;"><span class="stl_45 stl_21 stl_46">Fromthe &nbsp;</span></div>
					<div style="position:absolute; top:80.7571em; left:61.8701em;"><span class="stl_45 stl_21 stl_38">switching &nbsp;</span></div>
					<div style="position:absolute; top:82.9236em; left:61.5009em;"><span class="stl_45 stl_21 stl_47">datetothe &nbsp;</span></div>
					<div style="position:absolute; top:85.0901em; left:62.9411em;"><span class="stl_45 stl_21 stl_47">endof &nbsp;</span></div>
					<div style="position:absolute; top:78.5906em; left:71.7069em;"><span class="stl_45 stl_21 stl_48" style="word-spacing:1.3346em;">30June 01July2019 &nbsp;</span></div>
					<div style="position:absolute; top:80.7571em; left:72.5924em;"><span class="stl_45 stl_21 stl_38">2019 &nbsp;</span></div>
					<div style="position:absolute; top:78.8032em; left:14.356em;"><span class="stl_20 stl_21 stl_10">1</span></div>
					<div style="position:absolute; top:78.8032em; left:22.4006em;"><span class="stl_20 stl_21 stl_10">Viettel &nbsp;</span></div>
					<div style="position:absolute; top:87.2566em; left:61.2646em;"><span class="stl_45 stl_21 stl_38">14/11/2018 &nbsp;</span></div>
					<div style="position:absolute; top:110.3362em; left:12.0655em;"><span class="stl_31 stl_23 stl_10">3</span></div>
					<div style="position:absolute; top:112.0862em; left:12.0655em;"><span class="stl_31 stl_23 stl_10">4</span></div>
					<div style="position:absolute; top:110.2396em; left:12.8141em;"><span class="stl_32 stl_23 stl_10" style="word-spacing:0em;">During this time, both old and new number are valid. &nbsp;</span></div>
					<div style="position:absolute; top:111.9896em; left:12.6549em;"><span class="stl_32 stl_23 stl_10" style="word-spacing:0em;">During this time, when dial to the old number, user will receive the voice message from the system to remind about the new &nbsp;</span></div>
					<div style="position:absolute; top:113.7401em; left:12.0654em;"><span class="stl_32 stl_23 stl_10" style="word-spacing:0em;">net code number. &nbsp;</span></div>
					<div style="position:absolute; top:115.5862em; left:12.0655em;"><span class="stl_31 stl_23 stl_10">5</span></div>
					<div style="position:absolute; top:115.4896em; left:12.7688em;"><span class="stl_32 stl_23 stl_10" style="word-spacing:0em;">From this time, old number will be invalid &nbsp;</span></div>
					<div style="position:absolute; top:122.402em; left:68.6213em;"><span class="stl_24 stl_25 stl_30" style="word-spacing:-0.0118em;">KICC E-JOURNAL - Vol 4 &nbsp;</span></div>
					<div style="position:absolute; top:122.2674em; left:86.7539em;"><span class="stl_27 stl_28 stl_10">0</span></div>
					<div style="position:absolute; top:122.2674em; left:87.7733em;"><span class="stl_27 stl_28 stl_10">8</span></div>
				</div>
			</div>
		</div>
		<div class="stl_01">
			<div class="stl_02">
				<object data="http://35.240.140.159/images/201811/images/201811/img_19.svg" type="image/svg+xml" class="stl_03" style="position:absolute; width:98em; height:129.3333em;">
					<embed src="http://35.240.140.159/images/201811/images/201811/img_19.svg" type="image/svg+xml" class="stl_03" />
				</object>
			</div>
			<div class="layer">
				<div class="stl_04 stl_05">
					<div style="position:absolute; top:10.8438em; left:34.8269em;"><span class="stl_42 stl_43 stl_10">Old &nbsp;</span></div>
					<div style="position:absolute; top:12.5943em; left:34.8254em;"><span class="stl_42 stl_43 stl_10">Net &nbsp;</span></div>
					<div style="position:absolute; top:14.3448em; left:34.4504em;"><span class="stl_42 stl_43 stl_10">Code &nbsp;</span></div>
					<div style="position:absolute; top:10.8453em; left:41.0264em;"><span class="stl_42 stl_43 stl_10">New &nbsp;</span></div>
					<div style="position:absolute; top:12.5958em; left:41.3249em;"><span class="stl_42 stl_43 stl_10">Net &nbsp;</span></div>
					<div style="position:absolute; top:14.3463em; left:40.9499em;"><span class="stl_42 stl_43 stl_10">Code &nbsp;</span></div>
					<div style="position:absolute; top:11.4683em; left:63.4609em;"><span class="stl_42 stl_43 stl_10">Dual &nbsp;</span></div>
					<div style="position:absolute; top:13.2188em; left:62.2039em;"><span class="stl_42 stl_43 stl_10" style="word-spacing:0em;">dial time &nbsp;</span></div>
					<div style="position:absolute; top:11.4688em; left:70.88em;"><span class="stl_42 stl_43 stl_10" style="word-spacing:1.2768em;">Reminding Expiration &nbsp;</span></div>
					<div style="position:absolute; top:13.2193em; left:73.0235em;"><span class="stl_42 stl_43 stl_10" style="word-spacing:3.8628em;">time Date &nbsp;</span></div>
					<div style="position:absolute; top:11.7188em; left:22.3894em;"><span class="stl_42 stl_43 stl_10">Mobile &nbsp;</span></div>
					<div style="position:absolute; top:13.4693em; left:21.8434em;"><span class="stl_42 stl_43 stl_10">Operator &nbsp;</span></div>
					<div style="position:absolute; top:12.5938em; left:13.6232em;"><span class="stl_42 stl_43 stl_10">No. &nbsp;</span></div>
					<div style="position:absolute; top:12.4688em; left:47.9719em;"><span class="stl_42 stl_43 stl_10" style="word-spacing:0em;">Switching Date &nbsp;</span></div>
					<div style="position:absolute; top:17.5458em; left:34.2577em;"><span class="stl_20 stl_21 stl_10">0</span></div>
					<div style="position:absolute; top:20.7999em; left:34.2577em;"><span class="stl_20 stl_21 stl_10">0</span></div>
					<div style="position:absolute; top:24.0541em; left:34.2577em;"><span class="stl_20 stl_21 stl_10">0</span></div>
					<div style="position:absolute; top:27.3083em; left:34.2577em;"><span class="stl_20 stl_21 stl_10">0</span></div>
					<div style="position:absolute; top:30.5616em; left:34.2577em;"><span class="stl_20 stl_21 stl_10">0</span></div>
					<div style="position:absolute; top:17.5458em; left:35.1982em;"><span class="stl_20 stl_21 stl_10">123 &nbsp;</span></div>
					<div style="position:absolute; top:20.7999em; left:35.1982em;"><span class="stl_20 stl_21 stl_10">124 &nbsp;</span></div>
					<div style="position:absolute; top:24.0541em; left:35.1982em;"><span class="stl_20 stl_21 stl_10">125 &nbsp;</span></div>
					<div style="position:absolute; top:27.3083em; left:35.1982em;"><span class="stl_20 stl_21 stl_10">126 &nbsp;</span></div>
					<div style="position:absolute; top:30.5616em; left:35.1982em;"><span class="stl_20 stl_21 stl_10">127 &nbsp;</span></div>
					<div style="position:absolute; top:17.5458em; left:41.2281em;"><span class="stl_20 stl_21 stl_10">083 &nbsp;</span></div>
					<div style="position:absolute; top:20.7999em; left:41.2281em;"><span class="stl_20 stl_21 stl_10">084 &nbsp;</span></div>
					<div style="position:absolute; top:24.0541em; left:41.2281em;"><span class="stl_20 stl_21 stl_10">085 &nbsp;</span></div>
					<div style="position:absolute; top:27.3083em; left:41.2281em;"><span class="stl_20 stl_21 stl_10">081 &nbsp;</span></div>
					<div style="position:absolute; top:30.5616em; left:41.2281em;"><span class="stl_20 stl_21 stl_10">082 &nbsp;</span></div>
					<div style="position:absolute; top:17.5458em; left:48.6586em;"><span class="stl_20 stl_21 stl_10">24/09/2018 &nbsp;</span></div>
					<div style="position:absolute; top:20.8em; left:48.6586em;"><span class="stl_20 stl_21 stl_10">15/09/2018 &nbsp;</span></div>
					<div style="position:absolute; top:24.0541em; left:48.6586em;"><span class="stl_20 stl_21 stl_10">27/09/2018 &nbsp;</span></div>
					<div style="position:absolute; top:27.3083em; left:48.6586em;"><span class="stl_20 stl_21 stl_10">18/09/2018 &nbsp;</span></div>
					<div style="position:absolute; top:30.5616em; left:48.6586em;"><span class="stl_20 stl_21 stl_10">21/09/2018 &nbsp;</span></div>
					<div style="position:absolute; top:19.1158em; left:62.1302em;"><span class="stl_45 stl_21 stl_46">Fromthe &nbsp;</span></div>
					<div style="position:absolute; top:21.2823em; left:61.9535em;"><span class="stl_45 stl_21 stl_38">switching &nbsp;</span></div>
					<div style="position:absolute; top:23.4488em; left:61.5842em;"><span class="stl_45 stl_21 stl_47">datetothe &nbsp;</span></div>
					<div style="position:absolute; top:25.6153em; left:63.0245em;"><span class="stl_45 stl_21 stl_47">endof &nbsp;</span></div>
					<div style="position:absolute; top:19.1158em; left:71.7902em;"><span class="stl_45 stl_21 stl_48" style="word-spacing:1.3346em;">30June 01July2019 &nbsp;</span></div>
					<div style="position:absolute; top:21.2823em; left:72.6757em;"><span class="stl_45 stl_21 stl_38">2019 &nbsp;</span></div>
					<div style="position:absolute; top:19.4634em; left:14.4393em;"><span class="stl_20 stl_21 stl_10">2</span></div>
					<div style="position:absolute; top:19.4634em; left:20.7735em;"><span class="stl_20 stl_21 stl_10">Vinaphone &nbsp;</span></div>
					<div style="position:absolute; top:27.7818em; left:61.348em;"><span class="stl_45 stl_21 stl_38">14/11/2018 &nbsp;</span></div>
					<div style="position:absolute; top:34.4318em; left:34.2596em;"><span class="stl_20 stl_21 stl_10">0120 &nbsp;</span></div>
					<div style="position:absolute; top:40.5321em; left:34.2577em;"><span class="stl_20 stl_21 stl_10">0121 &nbsp;</span></div>
					<div style="position:absolute; top:46.6328em; left:34.2577em;"><span class="stl_20 stl_21 stl_10">0122 &nbsp;</span></div>
					<div style="position:absolute; top:52.7333em; left:34.2577em;"><span class="stl_20 stl_21 stl_10">0126 &nbsp;</span></div>
					<div style="position:absolute; top:58.834em; left:34.2577em;"><span class="stl_20 stl_21 stl_10">0128 &nbsp;</span></div>
					<div style="position:absolute; top:64.9347em; left:34.2577em;"><span class="stl_20 stl_21 stl_10">0186 &nbsp;</span></div>
					<div style="position:absolute; top:71.0353em; left:34.2577em;"><span class="stl_20 stl_21 stl_10">0188 &nbsp;</span></div>
					<div style="position:absolute; top:77.1359em; left:34.2577em;"><span class="stl_20 stl_21 stl_10">0199 &nbsp;</span></div>
					<div style="position:absolute; top:34.4318em; left:41.2299em;"><span class="stl_20 stl_21 stl_10">070 &nbsp;</span></div>
					<div style="position:absolute; top:40.5321em; left:41.2281em;"><span class="stl_20 stl_21 stl_10">079 &nbsp;</span></div>
					<div style="position:absolute; top:46.6328em; left:41.2281em;"><span class="stl_20 stl_21 stl_10">077 &nbsp;</span></div>
					<div style="position:absolute; top:52.7333em; left:41.2281em;"><span class="stl_20 stl_21 stl_10">076 &nbsp;</span></div>
					<div style="position:absolute; top:58.834em; left:41.2281em;"><span class="stl_20 stl_21 stl_10">078 &nbsp;</span></div>
					<div style="position:absolute; top:34.4318em; left:48.4532em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">From 15/09 &nbsp;</span></div>
					<div style="position:absolute; top:36.5988em; left:47.6594em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">to 24/09/2018 &nbsp;</span></div>
					<div style="position:absolute; top:35.9936em; left:14.4393em;"><span class="stl_20 stl_21 stl_10">3</span></div>
					<div style="position:absolute; top:35.9936em; left:21.2355em;"><span class="stl_20 stl_21 stl_10">Mobifone &nbsp;</span></div>
					<div style="position:absolute; top:40.5321em; left:48.9207em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">From 24/9 &nbsp;</span></div>
					<div style="position:absolute; top:42.6991em; left:48.1269em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">to 27/9/2018 &nbsp;</span></div>
					<div style="position:absolute; top:46.6328em; left:48.2571em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">From 27/09 &nbsp;</span></div>
					<div style="position:absolute; top:48.7998em; left:47.6576em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">to 04/10/2018 &nbsp;</span></div>
					<div style="position:absolute; top:52.7333em; left:48.4514em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">From 04/10 &nbsp;</span></div>
					<div style="position:absolute; top:54.9003em; left:47.6576em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">to 07/10/2018 &nbsp;</span></div>
					<div style="position:absolute; top:58.834em; left:48.4514em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">From 07/10 &nbsp;</span></div>
					<div style="position:absolute; top:61.001em; left:47.6576em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">to 10/10/2018 &nbsp;</span></div>
					<div style="position:absolute; top:64.9347em; left:41.2281em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.991em;">056 From</span><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;"> 15/09/2018 &nbsp;</span></div>
					<div style="position:absolute; top:67.1017em; left:47.4632em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.212em;">to 14/11/2018 &nbsp;</span></div>
					<div style="position:absolute; top:66.4968em; left:14.4393em;"><span class="stl_20 stl_21 stl_10">4</span></div>
					<div style="position:absolute; top:78.1494em; left:14.4393em;"><span class="stl_20 stl_21 stl_10">5</span></div>
					<div style="position:absolute; top:66.4968em; left:19.0685em;"><span class="stl_20 stl_21 stl_10">Vietnammobile &nbsp;</span></div>
					<div style="position:absolute; top:78.1494em; left:21.3986em;"><span class="stl_20 stl_21 stl_10">G-mobile &nbsp;</span></div>
					<div style="position:absolute; top:71.0353em; left:41.2281em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.991em;">058 From</span><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;"> 15/09/2018 &nbsp;</span></div>
					<div style="position:absolute; top:73.2023em; left:47.4632em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.212em;">to 14/11/2018 &nbsp;</span></div>
					<div style="position:absolute; top:77.1359em; left:41.2281em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.991em;">059 From</span><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;"> 15/09/2018 &nbsp;</span></div>
					<div style="position:absolute; top:79.3029em; left:47.4632em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.212em;">to 14/11/2018 &nbsp;</span></div>
					<div style="position:absolute; top:122.402em; left:68.6214em;"><span class="stl_24 stl_25 stl_30" style="word-spacing:-0.0118em;">KICC E-JOURNAL - Vol 4 &nbsp;</span></div>
					<div style="position:absolute; top:122.2674em; left:86.7539em;"><span class="stl_27 stl_28 stl_10">9</span></div>
				</div>
			</div>
		</div>
		<div class="stl_01">
			<div class="stl_02">
				<object data="http://35.240.140.159/images/201811/images/201811/img_20.svg" type="image/svg+xml" class="stl_03" style="position:absolute; width:98em; height:129.3333em;">
					<embed src="http://35.240.140.159/images/201811/images/201811/img_20.svg" type="image/svg+xml" class="stl_03" />
				</object>
			</div>
			<div class="layer">
				<div class="stl_04 stl_05">
					<div style="position:absolute; top:102.4928em; left:26.6204em;"><span class="stl_49 stl_07 stl_08" style="word-spacing:-0.0001em;">KICC HA NOI UPDATE &nbsp;</span></div>
				</div>
			</div>
		</div>
		<div class="stl_01">
			<div class="stl_02">
				<object data="http://35.240.140.159/images/201811/images/201811/img_23.svg" type="image/svg+xml" class="stl_03" style="position:absolute; width:98em; height:129.3333em;">
					<embed src="http://35.240.140.159/images/201811/images/201811/img_23.svg" type="image/svg+xml" class="stl_03" />
				</object>
			</div>
			<div class="layer">
				<div class="stl_04 stl_05">
					<div style="position:absolute; top:11.1476em; left:9.0378em;"><span class="stl_18 stl_19 stl_10">1</span></div>
					<div style="position:absolute; top:11.1476em; left:10.3158em;"><span class="stl_18 stl_19 stl_10" style="word-spacing:0.254em;">. KICC</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> to attend the ASEAN workshop</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> on</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> access</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> to information</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> of &nbsp;</span></div>
					<div style="position:absolute; top:14.7476em; left:11.8998em;"><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;">rural community &nbsp;</span></div>
					<div style="position:absolute; top:21.4689em; left:12.2987em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.014em;">On the 06 September of 2018, under the invitation of International Cooperation Department of MIC &nbsp;</span></div>
					<div style="position:absolute; top:23.6359em; left:12.2987em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.018em;">who hosted the ASEAN workshop on access to information of rural community, YJ Park, the director &nbsp;</span></div>
					<div style="position:absolute; top:25.8029em; left:12.2987em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.031em;">of Hanoi IT Cooperation Center</span><span class="stl_20 stl_21 stl_10" style="word-spacing:0.15em;"> had</span><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.031em;"> delivered a keynote speech titled “Bridging the Digital Divide</span><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.031em;"> in &nbsp;</span></div>
					<div style="position:absolute; top:27.9699em; left:12.2987em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">rural areas”. &nbsp;</span></div>
					<div style="position:absolute; top:75.3632em; left:9.0378em;"><span class="stl_18 stl_19 stl_10">2</span></div>
					<div style="position:absolute; top:75.3632em; left:10.3158em;"><span class="stl_18 stl_19 stl_10" style="word-spacing:0.254em;">. Korean</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> Startup</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> of</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> Vietnam</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> Silicon</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> Valley</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> (VSV) to visit</span><span class="stl_18 stl_19 stl_10" style="word-spacing:0em;"> KICC &nbsp;</span></div>
					<div style="position:absolute; top:82.8104em; left:12.2987em;"><span class="stl_20 stl_21 stl_38" style="word-spacing:0.054em;">On 05 September 2018, two promising &nbsp;</span></div>
					<div style="position:absolute; top:84.9774em; left:12.2987em;"><span class="stl_20 stl_21 stl_38" style="word-spacing:0.327em;">start-ups in Korea supported by the &nbsp;</span></div>
					<div style="position:absolute; top:87.1444em; left:12.2987em;"><span class="stl_20 stl_21 stl_50">VietnamSiliconValley(VSV)visitedKICC &nbsp;</span></div>
					<div style="position:absolute; top:89.3114em; left:12.2987em;"><span class="stl_20 stl_21 stl_38" style="word-spacing:0.109em;">and consulted and got advice on their &nbsp;</span></div>
					<div style="position:absolute; top:91.4784em; left:12.2987em;"><span class="stl_20 stl_21 stl_38" style="word-spacing:0.066em;">entry into the Vietnamese market. Two &nbsp;</span></div>
					<div style="position:absolute; top:93.6454em; left:12.2987em;"><span class="stl_20 stl_21 stl_51">start-upsinclude: &nbsp;</span></div>
					<div style="position:absolute; top:96.6447em; left:12.2987em;"><span class="stl_20 stl_21 stl_10">-</span></div>
					<div style="position:absolute; top:98.8117em; left:12.2987em;"><span class="stl_20 stl_21 stl_52">andartisticevents &nbsp;</span></div>
					<div style="position:absolute; top:96.6447em; left:13.8204em;"><span class="stl_20 stl_21 stl_38" style="word-spacing:0.125em;">Bitglim: Sharing platform for cultural &nbsp;</span></div>
					<div style="position:absolute; top:101.811em; left:12.2987em;"><span class="stl_20 stl_21 stl_10">-</span></div>
					<div style="position:absolute; top:101.811em; left:13.6719em;"><span class="stl_20 stl_21 stl_53">Rookies:e-learning,education,training &nbsp;</span></div>
					<div style="position:absolute; top:103.978em; left:12.2987em;"><span class="stl_20 stl_21 stl_38">platform &nbsp;</span></div>
					<div style="position:absolute; top:122.402em; left:68.6213em;"><span class="stl_24 stl_25 stl_30" style="word-spacing:-0.0118em;">KICC E-JOURNAL - Vol 4 &nbsp;</span></div>
					<div style="position:absolute; top:122.2674em; left:86.754em;"><span class="stl_27 stl_28 stl_10">1</span></div>
					<div style="position:absolute; top:122.2674em; left:87.7734em;"><span class="stl_27 stl_28 stl_10">0</span></div>
				</div>
			</div>
		</div>
		<div class="stl_01">
			<div class="stl_02">
				<object data="http://35.240.140.159/images/201811/images/201811/img_27.svg" type="image/svg+xml" class="stl_03" style="position:absolute; width:98em; height:129.3333em;">
					<embed src="http://35.240.140.159/images/201811/images/201811/img_27.svg" type="image/svg+xml" class="stl_03" />
				</object>
			</div>
			<div class="layer">
				<div class="stl_04 stl_05">
					<div style="position:absolute; top:12.0024em; left:9.3711em;"><span class="stl_18 stl_19 stl_10">3</span></div>
					<div style="position:absolute; top:12.0024em; left:10.5741em;"><span class="stl_18 stl_19 stl_39" style="word-spacing:0.254em;">. Introduction</span><span class="stl_18 stl_19 stl_39" style="word-spacing:0em;"> of</span><span class="stl_18 stl_19 stl_39" style="word-spacing:0em;"> Vietnamese</span><span class="stl_18 stl_19 stl_39" style="word-spacing:0em;"> ICT &nbsp;</span></div>
					<div style="position:absolute; top:15.6024em; left:12.5871em;"><span class="stl_18 stl_19 stl_39" style="word-spacing:0em;">industry for National HRD Institute &nbsp;</span></div>
					<div style="position:absolute; top:19.2024em; left:12.5871em;"><span class="stl_18 stl_19 stl_39" style="word-spacing:0em;">in Korea &nbsp;</span></div>
					<div style="position:absolute; top:25.1484em; left:12.2987em;"><span class="stl_20 stl_21 stl_38" style="word-spacing:0.202em;">On 31 August 2018, KICC held a workshop to &nbsp;</span></div>
					<div style="position:absolute; top:27.3154em; left:12.2987em;"><span class="stl_20 stl_21 stl_38" style="word-spacing:0.149em;">introduce Vietnam's ICT market’s attractiveness, &nbsp;</span></div>
					<div style="position:absolute; top:29.4824em; left:12.2987em;"><span class="stl_20 stl_21 stl_38" style="word-spacing:0.188em;">growth potential, di&#x1D;culties to the preliminary &nbsp;</span></div>
					<div style="position:absolute; top:31.6494em; left:12.2987em;"><span class="stl_20 stl_21 stl_54">o&#x1D;cialsofthegovernmentofKorea. &nbsp;</span></div>
					<div style="position:absolute; top:39.7472em; left:9.3711em;"><span class="stl_18 stl_19 stl_39" style="word-spacing:0.254em;">4. Shinhan</span><span class="stl_18 stl_19 stl_39" style="word-spacing:0em;"> Future’s Lab visited Hanoi</span><span class="stl_18 stl_19 stl_39" style="word-spacing:0em;"> IT</span><span class="stl_18 stl_19 stl_39" style="word-spacing:0em;"> Cooperation</span><span class="stl_18 stl_19 stl_39" style="word-spacing:0em;"> Center &nbsp;</span></div>
					<div style="position:absolute; top:46.7487em; left:12.2987em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.055em;">On the 02 October of 2018, KICC had a time &nbsp;</span></div>
					<div style="position:absolute; top:48.9157em; left:12.2987em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.192em;">to understand startup incubating activities &nbsp;</span></div>
					<div style="position:absolute; top:51.0827em; left:12.2987em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.278em;">of Shinhan Future’s Lab and shared each &nbsp;</span></div>
					<div style="position:absolute; top:53.2497em; left:12.2987em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.37em;">other’s opinion on how to network and &nbsp;</span></div>
					<div style="position:absolute; top:55.4167em; left:12.2987em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.485em;">access market e&#x1E;ectively for supporting &nbsp;</span></div>
					<div style="position:absolute; top:57.5837em; left:12.2987em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">Startups and Korean companies. &nbsp;</span></div>
					<div style="position:absolute; top:73.2001em; left:9.3711em;"><span class="stl_18 stl_19 stl_39" style="word-spacing:0.254em;">5. Vietnam</span><span class="stl_18 stl_19 stl_39" style="word-spacing:0em;"> Central Bank –</span><span class="stl_18 stl_19 stl_39" style="word-spacing:0em;"> KFTC – NIPA</span><span class="stl_18 stl_19 stl_39" style="word-spacing:0em;"> signed</span><span class="stl_18 stl_19 stl_39" style="word-spacing:0em;"> MOU &nbsp;</span></div>
					<div style="position:absolute; top:79.9501em; left:12.2989em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.323em;">On 15 October of 2018, Vietnam Central &nbsp;</span></div>
					<div style="position:absolute; top:82.1171em; left:12.2989em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.015em;">Bank, Korea Financial Telecommunications &amp; &nbsp;</span></div>
					<div style="position:absolute; top:84.2841em; left:12.2989em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.312em;">Clearings Institute and NIPA concluded a &nbsp;</span></div>
					<div style="position:absolute; top:86.4511em; left:12.2989em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.131em;">trilateral agreement at the Vietnam Central &nbsp;</span></div>
					<div style="position:absolute; top:88.6181em; left:12.2989em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.256em;">Bank. During the MOU signing ceremony, &nbsp;</span></div>
					<div style="position:absolute; top:90.7851em; left:12.2989em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.609em;">Shinhan Bank, Woori Bank, NongHyup, &nbsp;</span></div>
					<div style="position:absolute; top:92.9521em; left:12.2989em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.04em;">Datastream, and Finger Vina which is one of &nbsp;</span></div>
					<div style="position:absolute; top:95.1191em; left:12.2989em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.142em;">KICC Hanoi companies from the Korea and &nbsp;</span></div>
					<div style="position:absolute; top:97.2861em; left:12.2989em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.089em;">from vietnam side Le Minh Hung, Governor &nbsp;</span></div>
					<div style="position:absolute; top:99.4531em; left:12.2989em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.577em;">of SBV, Dr. Nguyen Kim Anh, Deputy &nbsp;</span></div>
					<div style="position:absolute; top:101.6201em; left:12.2989em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.144em;">Governor of SBV, Dr. Nguyen Toan Thang , &nbsp;</span></div>
					<div style="position:absolute; top:103.7871em; left:12.2989em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.819em;">Secretary General of VNBA attended. &nbsp;</span></div>
					<div style="position:absolute; top:105.9541em; left:12.2989em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.724em;">Participants had a discussion on the &nbsp;</span></div>
					<div style="position:absolute; top:108.1211em; left:12.2989em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.618em;">preparation of regulation issue in the &nbsp;</span></div>
					<div style="position:absolute; top:110.2881em; left:12.2989em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">context of Open API. &nbsp;</span></div>
					<div style="position:absolute; top:113.2874em; left:13.4649em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">VNBA : Vietnam Banks Association &nbsp;</span></div>
					<div style="position:absolute; top:115.4544em; left:13.4649em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">SBV : State Bank of Vietnam &nbsp;</span></div>
					<div style="position:absolute; top:122.402em; left:68.6214em;"><span class="stl_24 stl_25 stl_30" style="word-spacing:-0.0118em;">KICC E-JOURNAL - Vol 4 &nbsp;</span></div>
					<div style="position:absolute; top:122.2674em; left:86.754em;"><span class="stl_27 stl_28 stl_10">1</span></div>
					<div style="position:absolute; top:122.2674em; left:87.7734em;"><span class="stl_27 stl_28 stl_10">1</span></div>
				</div>
			</div>
		</div>
		<div class="stl_01">
			<div class="stl_02">
				<object data="http://35.240.140.159/images/201811/images/201811/img_30.svg" type="image/svg+xml" class="stl_03" style="position:absolute; width:98em; height:129.3333em;">
					<embed src="http://35.240.140.159/images/201811/images/201811/img_30.svg" type="image/svg+xml" class="stl_03" />
				</object>
			</div>
			<div class="layer">
				<div class="stl_04 stl_05">
					<div style="position:absolute; top:14.0301em; left:9.6358em;"><span class="stl_18 stl_19 stl_10">6</span></div>
					<div style="position:absolute; top:14.0301em; left:10.8388em;"><span class="stl_18 stl_19 stl_39" style="word-spacing:0.254em;">. Orangefarm</span><span class="stl_18 stl_19 stl_39" style="word-spacing:0em;"> visited &nbsp;</span></div>
					<div style="position:absolute; top:17.6301em; left:12.8518em;"><span class="stl_18 stl_19 stl_39" style="word-spacing:0em;">Hanoi IT Cooperation Center &nbsp;</span></div>
					<div style="position:absolute; top:24.6813em; left:12.5636em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.162em;">On 23 October of 2018, Orangefarm visited &nbsp;</span></div>
					<div style="position:absolute; top:26.8483em; left:12.5636em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.301em;">Hanoi IT Cooperation Center. Both parties &nbsp;</span></div>
					<div style="position:absolute; top:29.0153em; left:12.5636em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.236em;">discussed not only comparison of Vietnam &nbsp;</span></div>
					<div style="position:absolute; top:31.1823em; left:12.5636em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.002em;">and Korea’s startup ecosystem but also Korea &nbsp;</span></div>
					<div style="position:absolute; top:33.3493em; left:12.5636em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.784em;">startups’ strategy in entering Vietnam &nbsp;</span></div>
					<div style="position:absolute; top:35.5163em; left:12.5636em;"><span class="stl_20 stl_21 stl_10">market. &nbsp;</span></div>
					<div style="position:absolute; top:46.9646em; left:9.6358em;"><span class="stl_18 stl_19 stl_39" style="word-spacing:0.254em;">7. KICC</span><span class="stl_18 stl_19 stl_39" style="word-spacing:0em;"> attended Korea ICT</span><span class="stl_18 stl_19 stl_39" style="word-spacing:0em;"> Day &nbsp;</span></div>
					<div style="position:absolute; top:53.8991em; left:12.5636em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:-0.016em;">On 31 October of 2018, Korea ICT Day 2018 o&#x1E;ered Korean companies opportunities to entering the &nbsp;</span></div>
					<div style="position:absolute; top:56.0661em; left:12.5636em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.3em;">Vietnam market by providing best practice of Korea SW companies and business matching &nbsp;</span></div>
					<div style="position:absolute; top:58.2331em; left:12.5636em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.036em;">opportunities. At this event, YJ Park, the director of Hanoi IT Cooperation Center introduced about &nbsp;</span></div>
					<div style="position:absolute; top:60.4001em; left:12.5636em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0.168em;">KICC's support programs, activities and ICT companies who run their operators in the Hanoi IT &nbsp;</span></div>
					<div style="position:absolute; top:62.5671em; left:12.5636em;"><span class="stl_20 stl_21 stl_10" style="word-spacing:0em;">Cooperation Center. &nbsp;</span></div>
					<div style="position:absolute; top:122.4428em; left:68.611em;"><span class="stl_24 stl_25 stl_30" style="word-spacing:-0.0118em;">KICC E-JOURNAL - Vol 4 &nbsp;</span></div>
					<div style="position:absolute; top:122.3082em; left:86.7438em;"><span class="stl_27 stl_28 stl_10">1</span></div>
					<div style="position:absolute; top:122.3082em; left:87.7631em;"><span class="stl_27 stl_28 stl_10">2</span></div>
				</div>
			</div>
		</div>
		<div class="stl_01">
			<div class="stl_02">
				<object data="http://35.240.140.159/images/201811/images/201811/img_32.svg" type="image/svg+xml" class="stl_03" style="position:absolute; width:98em; height:129.3333em;">
					<embed src="http://35.240.140.159/images/201811/images/201811/img_32.svg" type="image/svg+xml" class="stl_03" />
				</object>
			</div>
			<div class="layer">
				<div class="stl_04 stl_05">
					<div style="position:absolute; top:37.2547em; left:16.5071em;"><span class="stl_55 stl_56 stl_38" style="word-spacing:0.05em;">THANK YOU! &nbsp;</span></div>
					<div style="position:absolute; top:110.3487em; left:19.6069em;"><span class="stl_57 stl_58 stl_10" style="word-spacing:0em;">Add: 25F Keangnam Landmark Tower - Nam Tu Liem- Hanoi &nbsp;</span></div>
					<div style="position:absolute; top:112.968em; left:24.5546em;"><span class="stl_57 stl_58 stl_10" style="word-spacing:0em;">Tel: 02473000674</span><span class="stl_59 stl_58 stl_10" style="word-spacing:0.7032em;"> I</span><span class="stl_57 stl_58 stl_10" style="word-spacing:0.4567em;"> Email:</span><span class="stl_57 stl_58 stl_10" style="word-spacing:0em;"> kicchanoi@nipa.kr &nbsp;</span></div>
				</div>
			</div>
		</div>
	</body>
</html>